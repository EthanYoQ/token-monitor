'use strict';

const { Client } = require('@xhayper/discord-rpc');
const { formatCurrencyFromUsd, normalizeCurrency } = require('../shared/currency');
const compactTokens = require('../shared/compactTokens');

const CLIENT_ID = '1507034330436862062';
const GITHUB_URL = 'https://github.com/Javis603/token-monitor';
const KNOWN_CLIENT_ASSETS = new Set([
  'claude', 'codex', 'opencode', 'hermes', 'openclaw', 'cursor', 'antigravity', 'cline',
  'amp', 'droid', 'kimi', 'qwen', 'grok', 'copilot', 'pi', 'omp', 'zed', 'kilo', 'commandcode', 'mimo', 'zcode', 'kiro', 'codebuddy', 'workbuddy', 'proma', 'qodercn', 'open-code-review', 'reasonix', 'dsh', 'cherrystudio', 'lmstudio', 'unsloth', 'devin',
  'gemini'
]);
const CLIENT_LABELS = {
  claude: 'Claude', codex: 'Codex', opencode: 'OpenCode', hermes: 'Hermes Agent',
  openclaw: 'OpenClaw', cursor: 'Cursor', antigravity: 'Antigravity', cline: 'Cline',
  amp: 'Amp', droid: 'Factory Droid', kimi: 'Kimi', qwen: 'Qwen', grok: 'Grok Build', copilot: 'GitHub Copilot',
  pi: 'Pi', omp: 'Oh My Pi', zed: 'Zed', kilo: 'Kilo', commandcode: 'Command Code', mimo: 'Xiaomi MiMo', zcode: 'ZCode', kiro: 'Kiro', codebuddy: 'CodeBuddy', workbuddy: 'WorkBuddy', proma: 'Proma', qodercn: 'Qoder CN', 'open-code-review': 'Open Code Review', reasonix: 'Reasonix', dsh: 'DeepSeek Harness', cherrystudio: 'Cherry Studio', lmstudio: 'LM Studio', unsloth: 'Unsloth', devin: 'Devin',
  gemini: 'Gemini'
};
const UPDATE_MIN_INTERVAL_MS = 15000;
const RECONNECT_DELAY_MS = 30000;

let client = null;
let isConnected = false;
let startTimestamp = 0;
let latestStats = null;
let latestCurrency = 'USD';
let latestCompactTokenUnits = 'western';
let latestLocale = 'en';
let pendingPayload = null;
let lastSentAt = 0;
let flushTimer = null;
let reconnectTimer = null;
let stopped = true;

function formatTokensCompact(value, unitSystem = 'western', locale = 'en') {
  return compactTokens.formatCompactTokens(value, unitSystem, locale);
}

function topClient(today) {
  const entries = Object.entries(today?.clients || {})
    .filter(([, v]) => Number(v) > 0)
    .sort((a, b) => Number(b[1]) - Number(a[1]));
  return entries[0]?.[0] || null;
}

function buildPayload(stats, currency = 'USD', compactTokenUnits = 'western', locale = 'en') {
  const today = stats?.periods?.today || { totalTokens: 0, costUsd: 0, clients: {} };
  const displayCurrency = normalizeCurrency(currency);
  const totalTokens = Number(today.totalTokens || 0);
  const base = {
    type: 0,
    largeImageKey: 'logo',
    largeImageText: 'Token Monitor',
    startTimestamp,
    buttons: [{ label: 'View on GitHub', url: GITHUB_URL }]
  };
  if (totalTokens === 0) {
    return { ...base, details: 'Token Monitor', state: 'No usage today' };
  }
  const top = topClient(today);
  const label = (top && CLIENT_LABELS[top]) || (top ? top : 'Active');
  const payload = {
    ...base,
    details: `${label} · ${formatTokensCompact(totalTokens, compactTokenUnits, locale)} tokens`,
    state: `${formatCurrencyFromUsd(today.costUsd, displayCurrency)} today`
  };
  if (top && KNOWN_CLIENT_ASSETS.has(top)) {
    payload.smallImageKey = top;
    payload.smallImageText = label;
  }
  return payload;
}

function flush() {
  flushTimer = null;
  if (!isConnected || !pendingPayload) return;
  lastSentAt = Date.now();
  const payload = pendingPayload;
  pendingPayload = null;
  client.user?.setActivity(payload).catch((error) => {
    console.log(`[discord-rpc] setActivity failed: ${error.message}`);
  });
}

function scheduleFlush() {
  if (!isConnected || !pendingPayload) return;
  const wait = Math.max(0, UPDATE_MIN_INTERVAL_MS - (Date.now() - lastSentAt));
  if (wait === 0) { flush(); return; }
  if (flushTimer) return;
  flushTimer = setTimeout(flush, wait);
}

function scheduleReconnect() {
  if (stopped || reconnectTimer) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connect();
  }, RECONNECT_DELAY_MS);
}

function connect() {
  if (stopped || client) return;
  client = new Client({ clientId: CLIENT_ID });
  client.on('ready', () => {
    isConnected = true;
    startTimestamp = Date.now();
    pendingPayload = buildPayload(latestStats, latestCurrency, latestCompactTokenUnits, latestLocale);
    flush();
  });
  client.on('disconnected', () => {
    isConnected = false;
    try { client?.destroy?.(); } catch (_) {}
    client = null;
    if (flushTimer) { clearTimeout(flushTimer); flushTimer = null; }
    scheduleReconnect();
  });
  client.login().catch((error) => {
    console.log(`[discord-rpc] connect failed: ${error.message}`);
    try { client?.destroy?.(); } catch (_) {}
    client = null;
    scheduleReconnect();
  });
}

function startDiscordRpc() {
  if (!stopped) return;
  stopped = false;
  connect();
}

function stopDiscordRpc() {
  stopped = true;
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  if (flushTimer) { clearTimeout(flushTimer); flushTimer = null; }
  pendingPayload = null;
  lastSentAt = 0;
  startTimestamp = 0;
  if (client) {
    try { client.user?.clearActivity?.(); } catch (_) {}
    try { client.destroy(); } catch (_) {}
  }
  client = null;
  isConnected = false;
}

function updateDiscordRpc(stats, currency = 'USD', options = {}) {
  latestStats = stats;
  latestCurrency = normalizeCurrency(currency);
  latestCompactTokenUnits = compactTokens.normalizeCompactTokenUnits(options.compactTokenUnits);
  latestLocale = options.locale || options.language || 'en';
  if (stopped) return;
  pendingPayload = buildPayload(stats, latestCurrency, latestCompactTokenUnits, latestLocale);
  scheduleFlush();
}

module.exports = { startDiscordRpc, stopDiscordRpc, updateDiscordRpc };
