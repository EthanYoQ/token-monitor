'use strict';

const hasOwn = (value, key) => Object.prototype.hasOwnProperty.call(value || {}, key);
const { filterReasonixSyntheticSessions } = require('../providers/reasonix/sessionGuard');

const PARTIAL_USAGE_CARRY_FIELDS = Object.freeze([
  'month',
  'allTime',
  'clientStatus',
  'clientHealth',
  'wslStatus',
  'periodWindows',
  'historyAvailable',
  'projectsEnabled',
  'allTimeProjectsOmitted',
  'allTimeProjectsIncomplete',
  'sessionDetailsOmitted',
  'periodProjectsOmitted',
  'nativeSessions',
  'nativeProjects',
  'syncUploadIntervalMs'
]);

function cloneValue(value, seen = new Map()) {
  if (value === null || typeof value !== 'object') return value;
  if (seen.has(value)) return seen.get(value);
  if (Array.isArray(value)) {
    const copy = [];
    seen.set(value, copy);
    for (const entry of value) copy.push(cloneValue(entry, seen));
    return copy;
  }
  const copy = Object.create(Object.getPrototypeOf(value) === null ? null : Object.prototype);
  seen.set(value, copy);
  for (const [key, entry] of Object.entries(value)) copy[key] = cloneValue(entry, seen);
  return copy;
}

function sanitizeUsagePeriods(value) {
  const next = cloneValue(value || {});
  const periods = next?.periods && typeof next.periods === 'object' ? next.periods : next;
  for (const periodName of ['today', 'month', 'allTime']) {
    const period = periods?.[periodName];
    if (period && typeof period === 'object' && hasOwn(period, 'sessions')) {
      period.sessions = filterReasonixSyntheticSessions(period.sessions);
    }
  }
  return next;
}

function normalizedEnvelope(value) {
  const envelope = {};
  for (const [key, entry] of Object.entries(value || {})) {
    if (entry !== undefined) envelope[key] = cloneValue(entry);
  }
  return envelope;
}

// The usage part is copied once on the way in and never mutated afterwards:
// every update builds a new part, and everything handed out is a copy. That is
// what lets a carried field be shared with the previous part by reference. A
// carried period in particular needs no second sanitize, because it was
// filtered when it arrived.
function mergeUsagePart(previous, incoming) {
  const next = sanitizeUsagePeriods(incoming || {});
  delete next.limits;
  if (!previous) return next;

  if (!hasOwn(next, 'history') && hasOwn(previous, 'history')) {
    next.history = previous.history;
  }

  const partial = !hasOwn(next, 'month') || !hasOwn(next, 'allTime');
  if (partial) {
    for (const field of PARTIAL_USAGE_CARRY_FIELDS) {
      if (!hasOwn(next, field) && hasOwn(previous, field)) {
        next[field] = previous[field];
      }
    }
  }
  return next;
}

function createDeviceState(options = {}) {
  const epoch = options.epoch ?? 0;
  const envelope = normalizedEnvelope(options.envelope);
  const onRecord = typeof options.onRecord === 'function' ? options.onRecord : null;
  let usagePart = null;
  let limitsPart = hasOwn(options, 'initialLimits') ? cloneValue(options.initialLimits) : undefined;
  // The parts as of the last publish. The parts are never mutated in place, so
  // holding them is enough to rebuild that record on demand.
  let published = null;
  let hasCompleteUsageBaseline = false;
  let revision = 0;
  let stopped = false;

  function accepts(meta) {
    if (stopped) return false;
    return !hasOwn(meta, 'epoch') || meta.epoch === epoch;
  }

  function recordFrom(parts) {
    const record = { ...cloneValue(parts.usagePart), ...cloneValue(envelope) };
    if (parts.limitsPart !== undefined) record.limits = cloneValue(parts.limitsPart);
    return record;
  }

  // One copy per publish. Every tick lands here, limits-only updates included,
  // and on a long history the record runs to megabytes, so each extra
  // defensive copy was a measurable stall on the main process. The observer and
  // the caller share that one copy; neither can reach the parts behind it.
  function publish(source, reason) {
    if (!usagePart || stopped) return null;
    published = { usagePart, limitsPart };
    const record = recordFrom(published);
    revision += 1;
    const meta = { revision, source, reason, epoch };
    if (onRecord) onRecord(record, meta);
    return record;
  }

  function updateUsage(summary, reason = 'usage', meta = {}) {
    if (!accepts(meta)) return null;
    usagePart = mergeUsagePart(usagePart, summary);
    if (hasOwn(usagePart, 'month') && hasOwn(usagePart, 'allTime')) {
      hasCompleteUsageBaseline = true;
    }
    if (meta.preview === true && !hasCompleteUsageBaseline) return null;
    return publish('usage', reason);
  }

  function updateLimits(limits, reason = 'limits', meta = {}) {
    if (!accepts(meta)) return null;
    limitsPart = cloneValue(limits);
    return publish('limits', reason);
  }

  function getSnapshot() {
    return published ? recordFrom(published) : null;
  }

  function stop() {
    stopped = true;
  }

  return {
    getSnapshot,
    stop,
    updateLimits,
    updateUsage
  };
}

module.exports = {
  createDeviceState
};
