'use strict';

// Reads OpenCode session metadata + per-exchange detail from opencode.db (SQLite).
// This is the only place that reads the DB for *sessions*; it mirrors the discovery and
// feature-detection used by ./opencodeLimits (node:sqlite, read-only, deps.sqlite seam).
// OpenCode has no jsonl transcript like Claude/Codex — everything lives in the DB.

const { discoverDbPaths } = require('./goLimits');
const path = require('node:path');

let sqlite = null;
try { sqlite = require('node:sqlite'); } catch (_) { sqlite = null; }

function num(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function isoFromMs(ms) {
  const n = Number(ms);
  if (!Number.isFinite(n) || n <= 0) return '';
  return new Date(n).toISOString();
}

function cleanText(text) {
  return String(text || '').replace(/\s+/g, ' ').trim();
}

function resolveSqlite(deps) {
  return deps.sqlite !== undefined ? deps.sqlite : sqlite;
}

function resolvePaths(deps) {
  return deps.dbPaths || discoverDbPaths(deps.env || process.env);
}

function openDb(dbPath, sqliteMod) {
  const db = new sqliteMod.DatabaseSync(dbPath, { readOnly: true });
  db.exec('PRAGMA busy_timeout = 250');
  return db;
}

// ---------------------------------------------------------------------------
// Session metadata (for the list-row timestamps + title)
// ---------------------------------------------------------------------------
function readSessionMeta(sessionIds, deps = {}) {
  const ids = Array.from(sessionIds || []).filter(Boolean).map(String);
  const out = new Map();
  if (ids.length === 0) return out;
  const sqliteMod = resolveSqlite(deps);
  if (!sqliteMod) return out;

  const placeholders = ids.map(() => '?').join(',');
  for (const dbPath of resolvePaths(deps)) {
    let db;
    try {
      db = openDb(dbPath, sqliteMod);
      const columns = new Set(db.prepare('PRAGMA table_info(session)').all().map((column) => String(column.name)));
      const directory = columns.has('directory') ? "COALESCE(directory,'')" : "''";
      const messageColumns = new Set(db.prepare('PRAGMA table_info(message)').all().map((column) => String(column.name)));
      const lastMessageBySession = new Map();
      // The newest assistant row's `finish` is OpenCode's turn-end signal, the
      // same fact Claude states as `stop_reason`: `stop` means the model
      // finished its answer, `tool-calls` means it paused to run tools and is
      // still mid-turn. Read beside the last-message timestamp so one query
      // answers both, and only `stop` counts as finished.
      // Tri-state per session: true = the newest word was a completed answer,
      // false = a prompt is waiting on one, absent = no evidence. A boolean
      // pair could not express the third case, and collapsing it into "omit"
      // is what let a stale completion survive.
      const turnEndedBySession = new Map();
      if (messageColumns.has('session_id') && (messageColumns.has('data') || messageColumns.has('time_created'))) {
        const jsonCreated = messageColumns.has('data')
          ? "CASE WHEN json_valid(data) THEN CAST(json_extract(data,'$.time.created') AS INTEGER) END"
          : 'NULL';
        const storedCreated = messageColumns.has('time_created') ? 'time_created' : 'NULL';
        const messageSql = `SELECT session_id AS sessionId,
                                   MAX(CAST(COALESCE(${jsonCreated}, ${storedCreated}) AS INTEGER)) AS lastMessageMs
                            FROM message
                            WHERE session_id IN (${placeholders})
                            GROUP BY session_id`;
        for (const row of db.prepare(messageSql).all(...ids)) {
          lastMessageBySession.set(String(row.sessionId), row.lastMessageMs);
        }
        if (messageColumns.has('data')) {
          // One row per session: the newest assistant message. Windowed rather
          // than grouped, because the finish value belongs to that single row
          // and SQLite's bare-column grouping would pick an arbitrary one.
          // (A correlated subquery is the obvious alternative, but `inner` is a
          // reserved word and the resulting syntax error is swallowed by the
          // caller's catch, which reads as "this session has no metadata".)
          // The boundary belongs to the newest message, not to the newest
          // assistant message: a prompt accepted after a completion has already
          // started the next turn, so that completion no longer describes the
          // current one. Taking the newest assistant row unconditionally latched
          // the previous `stop` and marked a freshly prompted session finished.
          // Order by the same effective timestamp the query above used rather
          // than an unconditional `time_created, id`: the guard only requires
          // `session_id` plus `data` or `time_created`, so a schema without
          // `id` (or without `time_created`) would make SQLite reject this
          // query, and the caller's catch would read that as "this session has
          // no metadata" and blank its title and timestamps.
          const orderId = messageColumns.has('id') ? 'id' : 'rowid';
          const finishSql = `SELECT sessionId, role, finish FROM (
                               SELECT session_id AS sessionId,
                                      json_extract(data,'$.role') AS role,
                                      json_extract(data,'$.finish') AS finish,
                                      ROW_NUMBER() OVER (
                                        PARTITION BY session_id
                                        ORDER BY CAST(COALESCE(${jsonCreated}, ${storedCreated}) AS INTEGER) DESC,
                                                 ${orderId} DESC
                                      ) AS rank
                               FROM message
                               WHERE session_id IN (${placeholders})
                                 AND json_valid(data)
                             ) WHERE rank = 1`;
          for (const row of db.prepare(finishSql).all(...ids)) {
            const sessionId = String(row.sessionId);
            const role = String(row.role || '');
            const finish = String(row.finish || '');
            if (role === 'assistant') {
              // A row with no `finish` is the pre-v2 shape, which recorded no
              // boundary at all and therefore is not evidence of one.
              if (!finish) continue;
              // Only a pause to run tools leaves the turn open. Every other
              // reason OpenCode can record is terminal — it stops the loop and
              // waits for the next prompt — including `length` (the output
              // budget ran out) and `content-filter`. Treating those as
              // "still generating" held the running mark for the whole recency
              // window after the model had already stopped.
              turnEndedBySession.set(sessionId, finish !== 'tool-calls');
            } else if (role === 'user') {
              // The newest message is the user's, so a prompt is waiting on an
              // answer and the previous completion no longer describes this turn.
              turnEndedBySession.set(sessionId, false);
            }
          }
        }
      }
      const sql = `SELECT id, COALESCE(title,'') AS title, ${directory} AS directory, time_created AS created
                   FROM session WHERE id IN (${placeholders})`;
      for (const r of db.prepare(sql).all(...ids)) {
        const id = String(r.id);
        if (out.has(id)) continue;
        const startedAt = isoFromMs(r.created);
        // session.time_updated can change for metadata/background work. Only a
        // persisted message is real usage activity; a message-less session
        // falls back to its creation time instead of masquerading as recent.
        const lastUsedAt = isoFromMs(lastMessageBySession.get(id)) || startedAt;
        const meta = { startedAt, lastUsedAt, title: String(r.title || '') };
        if (r.directory) meta.projectPath = String(r.directory);
        // A completion ends the turn and a waiting prompt clears one; a
        // `tool-calls` pause is still work in progress (a `false`), and a session
        // whose newest row states nothing is left without evidence rather than
        // guessed at.
        const ended = turnEndedBySession.get(id);
        if (ended !== undefined) meta.turnEnded = ended;
        out.set(id, meta);
      }
    } catch (_) { /* skip unreadable db */ } finally {
      if (db) { try { db.close(); } catch (_) {} }
    }
  }
  return out;
}

function readSessionMetaForHome(sessionIds, home, deps = {}) {
  const env = deps.env || process.env;
  const scopedEnv = {
    ...env,
    OPENCODE_DB: '',
    XDG_DATA_HOME: path.join(home, '.local', 'share'),
    HOME: home,
    USERPROFILE: home
  };
  return readSessionMeta(sessionIds, { ...deps, dbPaths: discoverDbPaths(scopedEnv) });
}

function resolveSessionMetadata(sessionIds, context) {
  const { deps, home, projectIdentity, resolveProjects } = context;
  const readMetadata = deps.readOpencodeMeta || (deps.scopedHome
    ? (ids) => readSessionMetaForHome(ids, home, deps.opencodeDeps)
    : (ids) => readSessionMeta(ids, deps.opencodeDeps));
  const result = new Map();
  for (const [sessionId, meta] of readMetadata(sessionIds)) {
    const startedAt = meta.startedAt || '';
    const lastUsedAt = meta.lastUsedAt || startedAt;
    const identity = resolveProjects ? projectIdentity(meta.projectPath) : {};
    const title = String(meta.title || '').trim();
    if (startedAt || lastUsedAt || identity.projectId || title) {
      result.set(sessionId, {
        startedAt,
        lastUsedAt,
        ...identity,
        title,
        // Forwarded in both directions: `false` is evidence of an active turn
        // and has to reach the merge to clear a `true` from an earlier tick.
        ...(meta.turnEnded === undefined ? {} : { turnEnded: meta.turnEnded === true })
      });
    }
  }
  return result;
}

// ---------------------------------------------------------------------------
// Session detail events (neutral shape consumed by sessionDetail.js)
// ---------------------------------------------------------------------------
const MESSAGES_SQL =
  `SELECT id,
          CAST(COALESCE(json_extract(data,'$.time.created'), time_created) AS INTEGER) AS createdMs,
          json_extract(data,'$.role')             AS role,
          json_extract(data,'$.cost')             AS cost,
          json_extract(data,'$.tokens.input')     AS tInput,
          json_extract(data,'$.tokens.output')    AS tOutput,
          json_extract(data,'$.tokens.reasoning') AS tReasoning,
          json_extract(data,'$.tokens.cache.read')  AS tCacheRead,
          json_extract(data,'$.tokens.cache.write') AS tCacheWrite
   FROM message
   WHERE session_id = ? AND json_valid(data)
   ORDER BY createdMs ASC, id ASC`;

const PARTS_SQL =
  `SELECT message_id AS messageId,
          json_extract(data,'$.type') AS type,
          json_extract(data,'$.text') AS text,
          json_extract(data,'$.tool') AS tool
   FROM part
   WHERE session_id = ? AND json_valid(data)
   ORDER BY time_created ASC, id ASC`;

function mapTokens(r) {
  const input = num(r.tInput);
  const output = num(r.tOutput);
  const reasoning = num(r.tReasoning);
  const cacheRead = num(r.tCacheRead);
  const cacheWrite = num(r.tCacheWrite);
  // Match how tokscale totals a session: input + output + cacheRead + cacheWrite. OpenCode's
  // stored `tokens.total` ADDS reasoning on top of that, so trusting it over-counts vs the
  // session card. Keep reasoning informational only — same convention as Claude/Codex.
  const total = input + output + cacheRead + cacheWrite;
  return { input, output, cacheRead, cacheWrite, reasoning, total };
}

function buildEvents(messages, parts) {
  const textByMessage = new Map();
  const toolsByMessage = new Map();
  for (const p of parts) {
    if (p.type === 'text' && p.text) {
      if (!textByMessage.has(p.messageId)) textByMessage.set(p.messageId, []);
      textByMessage.get(p.messageId).push(String(p.text));
    } else if (p.type === 'tool' && p.tool) {
      if (!toolsByMessage.has(p.messageId)) toolsByMessage.set(p.messageId, []);
      toolsByMessage.get(p.messageId).push(String(p.tool));
    }
  }

  const events = [];
  let sessionCost = 0;
  for (const m of messages) {
    const timestamp = isoFromMs(m.createdMs);
    if (m.role === 'user') {
      // Each user message is one exchange boundary (even with empty text).
      const text = cleanText((textByMessage.get(m.id) || []).join(' '));
      events.push({ kind: 'prompt', timestamp, text });
    } else if (m.role === 'assistant') {
      const cost = num(m.cost);
      sessionCost += cost;
      const tools = Array.from(new Set(toolsByMessage.get(m.id) || []));
      events.push({ kind: 'turn', timestamp, tokens: mapTokens(m), tools, cost });
    }
  }
  return { events, sessionCost };
}

function readSessionEvents(sessionId, deps = {}) {
  const empty = { found: false, events: [], sessionCost: 0 };
  const id = String(sessionId || '');
  if (!id) return empty;
  const sqliteMod = resolveSqlite(deps);
  if (!sqliteMod) return empty;

  for (const dbPath of resolvePaths(deps)) {
    let db;
    try {
      db = openDb(dbPath, sqliteMod);
      const messages = db.prepare(MESSAGES_SQL).all(id);
      if (messages.length === 0) continue;
      const parts = db.prepare(PARTS_SQL).all(id);
      const { events, sessionCost } = buildEvents(messages, parts);
      return { found: true, events, sessionCost };
    } catch (_) { /* skip unreadable db */ } finally {
      if (db) { try { db.close(); } catch (_) {} }
    }
  }
  return empty;
}

module.exports = { readSessionMeta, readSessionMetaForHome, readSessionEvents, resolveSessionMetadata };
