'use strict';

// Portable (Node-free) usage-history core. Mirrors usage.js conventions so the
// Cloudflare Worker can import it. Pure functions only — no I/O.
const { REASONIX_CLIENT } = require('./providers/reasonix/paths');

const TOKSCALE_CLIENT_ALIASES = new Map([
  ['antigravity-cli', 'antigravity'],
  ['antigravity-extension', 'antigravity'],
  // `micode` is tokscale's id for MiMo Code, a fossil of the path typo its PR
  // #784 fixed. Token Monitor's id is `mimo`, so both upstream spellings fold
  // onto it — including plain `micode`, which is what every device and stored
  // history record written before the rename still says.
  ['micode', 'mimo'],
  ['micode-desktop', 'mimo'],
  ['kilocode', 'kilo'],
  ['devin-cli', 'devin'],
  ['devin-desktop', 'devin']
]);

// Canonical Token Monitor identity for client ids emitted by Tokscale. Keep
// this small and exact: product-name heuristics still belong to usage.js, while
// history and the durable archive need the same raw-id aliases as live usage.
function normalizeTokscaleClientName(value) {
  const raw = String(value || '').trim().toLowerCase();
  if (!raw) return null;
  return TOKSCALE_CLIENT_ALIASES.get(raw) || raw;
}

function normalizeTokscaleModelNameForClient(value, client) {
  const model = String(value ?? '').trim();
  if (normalizeTokscaleClientName(client) === 'cursor' && /^(?:auto|default)$/i.test(model)) {
    return 'cursor-auto';
  }
  return model;
}

// A graph/day component summary is keyed by the source model labels. Its
// per-model buckets can follow a Cursor rename only if no other client shares
// the old label; otherwise the aggregate has no client split to recover.
function normalizeTokscaleModelComponentSummary(summary, rows) {
  if (!summary?.perModel) return summary;
  const renames = new Map();
  for (const row of rows || []) {
    const model = String(row?.modelId || row?.model || row?.model_id || 'unknown');
    const canonical = normalizeTokscaleModelNameForClient(model, row?.client);
    if (renames.has(model) && renames.get(model) !== canonical) return null;
    renames.set(model, canonical);
  }
  if (![...renames].some(([before, after]) => before !== after)) return summary;
  const perModel = {};
  for (const [model, components] of Object.entries(summary.perModel)) {
    const key = renames.get(model) || model;
    const previous = perModel[key];
    perModel[key] = previous ? {
      cacheReadTokens: num(previous.cacheReadTokens) + num(components?.cacheReadTokens),
      cacheWriteTokens: num(previous.cacheWriteTokens) + num(components?.cacheWriteTokens),
      outputTokens: num(previous.outputTokens) + num(components?.outputTokens),
      unclassifiedTokens: num(previous.unclassifiedTokens) + num(components?.unclassifiedTokens)
    } : components;
  }
  return { ...summary, perModel };
}

function num(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Number(value.replace(/[$,]/g, ''));
    if (Number.isFinite(parsed)) return parsed;
  }
  return 0;
}

function normalizeTimeMetrics(value) {
  if (!value || typeof value !== 'object') return null;
  return {
    totalActiveTimeMs: num(value.totalActiveTimeMs ?? value.total_active_time_ms),
    longestContinuousMs: num(value.longestContinuousMs ?? value.longest_continuous_ms),
    maxConcurrentSessions: num(value.maxConcurrentSessions ?? value.max_concurrent_sessions),
    sessionCount: num(value.sessionCount ?? value.session_count)
  };
}

// Tokscale emits these clients' reasoning as a disjoint JSON bucket. History
// uses the same reasoning-inclusive public output convention as usage.js.
// zcode/opencode: tokscale subtracts the reasoning overlap out of `output`
// (their source DBs are reasoning-inclusive), so it has to be added back here.
const TOKSCALE_DISJOINT_REASONING_CLIENTS = new Set([REASONIX_CLIENT, 'codex', 'droid', 'dsh', 'zcode', 'opencode']);

function hasDisjointReasoning(client) {
  return TOKSCALE_DISJOINT_REASONING_CLIENTS.has(String(client).trim().toLowerCase());
}

function sumTokens(breakdown, client = '') {
  if (!breakdown || typeof breakdown !== 'object') return 0;
  return num(breakdown.input) + num(breakdown.output)
    + num(breakdown.cacheRead) + num(breakdown.cacheWrite)
    + (hasDisjointReasoning(client) ? num(breakdown.reasoning) : 0);
}

function sumOutputTokens(breakdown, client = '') {
  if (!breakdown || typeof breakdown !== 'object') return 0;
  return num(breakdown.output)
    + (hasDisjointReasoning(client) ? num(breakdown.reasoning) : 0);
}

function componentValues(value, totalTokens, exact) {
  const cacheReadTokens = Math.max(0, num(value?.cacheReadTokens));
  const cacheWriteTokens = Math.max(0, num(value?.cacheWriteTokens));
  const outputTokens = Math.max(0, num(value?.outputTokens));
  if (cacheReadTokens + cacheWriteTokens + outputTokens > totalTokens) return null;
  const unclassifiedTokens = Math.min(
    totalTokens - cacheReadTokens - cacheWriteTokens - outputTokens,
    Math.max(0, num(value?.unclassifiedTokens
      ?? (exact ? 0 : totalTokens - cacheReadTokens - cacheWriteTokens - outputTokens)))
  );
  return { cacheReadTokens, cacheWriteTokens, outputTokens, unclassifiedTokens };
}

function applyComponentSummary(summary, totalTokens, perClient, perModel) {
  if (!summary || typeof summary !== 'object') return null;
  const exact = summary.tokenComponentsAvailable === true;
  const totals = componentValues(summary, totalTokens, exact);
  if (!totals) return null;
  const clients = {};
  for (const [key, value] of Object.entries(perClient)) {
    const components = componentValues(summary.perClient?.[key], num(value.tokens), exact);
    if (!components) return null;
    clients[key] = components;
  }
  const models = {};
  for (const [key, value] of Object.entries(perModel)) {
    const components = componentValues(summary.perModel?.[key], num(value.tokens), exact);
    if (!components) return null;
    models[key] = components;
  }
  return { totals, clients, models };
}

// Folds tokscale `graph` output (contributions[].clients[]) into a per-day shape where a
// day's total always equals the sum of its perClient and perModel stacks.
function parseGraphResult(raw) {
  const contributions = [];
  const rows = raw && Array.isArray(raw.contributions) ? raw.contributions : [];
  for (const row of rows) {
    if (!row || typeof row !== 'object') continue;
    const date = String(row.date || '').slice(0, 10);
    if (!date) continue;
    const perClient = {};
    const perModel = {};
    let tokens = 0;
    let cost = 0;
    let messages = 0;
    let cacheReadTokens = 0;
    let cacheWriteTokens = 0;
    let outputTokens = 0;
    let unclassifiedTokens = 0;
    let tokenComponentsAvailable = true;
    const clientRows = Array.isArray(row.clients) ? row.clients : [];
    for (const c of clientRows) {
      if (!c || typeof c !== 'object') continue;
      const client = normalizeTokscaleClientName(c.client) || 'unknown';
      const model = normalizeTokscaleModelNameForClient(c.modelId || c.model || c.model_id || 'unknown', client);
      const t = sumTokens(c.tokens, client);
      const cst = num(c.cost);
      const cacheRead = num(c.tokens?.cacheRead ?? c.tokens?.cache_read);
      const cacheWrite = num(c.tokens?.cacheWrite ?? c.tokens?.cache_write);
      const output = sumOutputTokens(c.tokens, client);
      const componentsAvailable = c.tokenComponentsAvailable !== false;
      const hasExplicitUnclassified = Object.prototype.hasOwnProperty.call(c, 'unclassifiedTokens')
        || Object.prototype.hasOwnProperty.call(c, 'unclassified_tokens');
      const unclassified = Math.min(t, Math.max(0, hasExplicitUnclassified
        ? num(c.unclassifiedTokens ?? c.unclassified_tokens)
        : (t > 0 && !componentsAvailable ? t : 0)));
      // Reasonix's `messages` field is a provider request count, not user turns.
      // Keep it out of Token Monitor's message/activity semantics; its tokens and
      // cost still contribute normally to the history totals.
      const msg = String(client).trim().toLowerCase() === REASONIX_CLIENT ? 0 : num(c.messages);
      tokens += t;
      cost += cst;
      messages += msg;
      cacheReadTokens += cacheRead;
      cacheWriteTokens += cacheWrite;
      outputTokens += output;
      unclassifiedTokens += unclassified;
      tokenComponentsAvailable = tokenComponentsAvailable
        && (t === 0 || (componentsAvailable && unclassified === 0));
      const pc = perClient[client] || (perClient[client] = {
        tokens: 0, cost: 0, messages: 0, unclassifiedTokens: 0
      });
      pc.tokens += t; pc.cost += cst; pc.messages += msg;
      if (cacheRead > 0) pc.cacheReadTokens = num(pc.cacheReadTokens) + cacheRead;
      if (cacheWrite > 0) pc.cacheWriteTokens = num(pc.cacheWriteTokens) + cacheWrite;
      if (output > 0) pc.outputTokens = num(pc.outputTokens) + output;
      pc.unclassifiedTokens += unclassified;
      const pm = perModel[model] || (perModel[model] = {
        tokens: 0, cost: 0, unclassifiedTokens: 0
      });
      pm.tokens += t; pm.cost += cst;
      if (cacheRead > 0) pm.cacheReadTokens = num(pm.cacheReadTokens) + cacheRead;
      if (cacheWrite > 0) pm.cacheWriteTokens = num(pm.cacheWriteTokens) + cacheWrite;
      if (output > 0) pm.outputTokens = num(pm.outputTokens) + output;
      pm.unclassifiedTokens += unclassified;
    }
    const componentSummary = applyComponentSummary(
      normalizeTokscaleModelComponentSummary(row.tokenComponentSummary, clientRows),
      tokens,
      perClient,
      perModel
    );
    if (componentSummary) {
      cacheReadTokens = componentSummary.totals.cacheReadTokens;
      cacheWriteTokens = componentSummary.totals.cacheWriteTokens;
      outputTokens = componentSummary.totals.outputTokens;
      unclassifiedTokens = componentSummary.totals.unclassifiedTokens;
      tokenComponentsAvailable = unclassifiedTokens === 0;
      for (const [client, value] of Object.entries(perClient)) {
        value.cacheReadTokens = componentSummary.clients[client].cacheReadTokens;
        value.cacheWriteTokens = componentSummary.clients[client].cacheWriteTokens;
        value.outputTokens = componentSummary.clients[client].outputTokens;
        value.unclassifiedTokens = componentSummary.clients[client].unclassifiedTokens;
        tokenComponentsAvailable = tokenComponentsAvailable && value.unclassifiedTokens === 0;
      }
      for (const [model, value] of Object.entries(perModel)) {
        value.cacheReadTokens = componentSummary.models[model].cacheReadTokens;
        value.cacheWriteTokens = componentSummary.models[model].cacheWriteTokens;
        value.outputTokens = componentSummary.models[model].outputTokens;
        value.unclassifiedTokens = componentSummary.models[model].unclassifiedTokens;
        tokenComponentsAvailable = tokenComponentsAvailable && value.unclassifiedTokens === 0;
      }
    }
    contributions.push({
      date,
      tokens,
      cost,
      messages,
      cacheReadTokens,
      cacheWriteTokens,
      outputTokens,
      unclassifiedTokens,
      tokenComponentsAvailable,
      activeTimeMs: num(row.activeTimeMs ?? row.active_time_ms),
      perClient,
      perModel
    });
  }
  const timeMetrics = normalizeTimeMetrics(raw?.timeMetrics ?? raw?.time_metrics);
  return timeMetrics ? { contributions, timeMetrics } : { contributions };
}

function intensityBucket(value, max) {
  if (max <= 0) return 0;
  const ratio = num(value) / max;
  return ratio >= 0.75 ? 4 : ratio >= 0.5 ? 3 : ratio >= 0.25 ? 2 : ratio > 0 ? 1 : 0;
}

// Preserve the legacy cost-based .intensity field for mixed-version hubs/widgets,
// while exposing explicit fields for new metric-aware renderers. Mutates and returns
// the same array.
function computeIntensities(days) {
  const list = Array.isArray(days) ? days : [];
  let maxTokens = 0;
  let maxCost = 0;
  for (const d of list) {
    maxTokens = Math.max(maxTokens, num(d.tokens));
    maxCost = Math.max(maxCost, num(d.cost));
  }
  for (const d of list) {
    d.tokenIntensity = intensityBucket(d.tokens, maxTokens);
    d.costIntensity = intensityBucket(d.cost, maxCost);
    d.intensity = d.costIntensity;
  }
  return list;
}

function dayKeyAddDays(key, delta) {
  const ms = Date.parse(`${key}T00:00:00Z`) + delta * 86400000;
  return new Date(ms).toISOString().slice(0, 10);
}

// Every day key reaching this module is a local calendar day: the collector stamps
// contributions with `localTodayKey()` and `computePeriodWindows` ends each window at
// the next *local* midnight. Resolving "today" from `toISOString()` instead keys the
// boundary in UTC, which east of UTC drops the current local day out of the rolling
// window and west of UTC starts the streak walk on a day that holds no data.
function localDayKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

// A day is "active" when tokens > 0. currentStreak = consecutive active days ending at
// todayKey (0 if today is inactive). longestStreak = longest run anywhere.
function computeStreaks(days, todayKey) {
  const active = new Set();
  for (const d of (Array.isArray(days) ? days : [])) {
    if (num(d.tokens) > 0) active.add(String(d.date).slice(0, 10));
  }
  // current: walk back from todayKey while active
  let currentStreak = 0;
  let cursor = String(todayKey).slice(0, 10);
  while (active.has(cursor)) {
    currentStreak += 1;
    cursor = dayKeyAddDays(cursor, -1);
  }
  // longest: scan sorted active dates for consecutive runs
  const sorted = [...active].sort();
  let longestStreak = 0;
  let run = 0;
  let prev = null;
  for (const key of sorted) {
    run = (prev !== null && key === dayKeyAddDays(prev, 1)) ? run + 1 : 1;
    longestStreak = Math.max(longestStreak, run);
    prev = key;
  }
  return { currentStreak, longestStreak };
}

function addPerClient(target, source, includeTokenComponents = false) {
  for (const [rawClient, v] of Object.entries(source || {})) {
    const client = normalizeTokscaleClientName(rawClient) || rawClient;
    const t = target[client] || (target[client] = { tokens: 0, cost: 0, messages: 0 });
    t.tokens += num(v.tokens); t.cost += num(v.cost); t.messages += num(v.messages);
    if (includeTokenComponents) {
      if (num(v.cacheReadTokens) > 0) t.cacheReadTokens = num(t.cacheReadTokens) + num(v.cacheReadTokens);
      if (num(v.cacheWriteTokens) > 0) t.cacheWriteTokens = num(t.cacheWriteTokens) + num(v.cacheWriteTokens);
      if (num(v.outputTokens) > 0) t.outputTokens = num(t.outputTokens) + num(v.outputTokens);
      const unclassifiedTokens = unclassifiedTokensFor(v);
      if (unclassifiedTokens > 0) t.unclassifiedTokens = num(t.unclassifiedTokens) + unclassifiedTokens;
    }
  }
}

function addPerModel(target, source, includeTokenComponents = false) {
  for (const [model, v] of Object.entries(source || {})) {
    const t = target[model] || (target[model] = { tokens: 0, cost: 0 });
    t.tokens += num(v.tokens); t.cost += num(v.cost);
    if (includeTokenComponents) {
      if (num(v.cacheReadTokens) > 0) t.cacheReadTokens = num(t.cacheReadTokens) + num(v.cacheReadTokens);
      if (num(v.cacheWriteTokens) > 0) t.cacheWriteTokens = num(t.cacheWriteTokens) + num(v.cacheWriteTokens);
      if (num(v.outputTokens) > 0) t.outputTokens = num(t.outputTokens) + num(v.outputTokens);
      const unclassifiedTokens = unclassifiedTokensFor(v);
      // Zero is provenance: it distinguishes a known input remainder from an
      // unknown one when another model makes the merged day inexact.
      t.unclassifiedTokens = num(t.unclassifiedTokens) + unclassifiedTokens;
    }
  }
}

function unclassifiedTokensFor(value) {
  if (!value || typeof value !== 'object') return 0;
  if (Object.prototype.hasOwnProperty.call(value, 'unclassifiedTokens')) {
    return Math.min(
      Math.max(0, num(value.tokens)),
      Math.max(0, num(value.unclassifiedTokens))
    );
  }
  return value.tokenComponentsAvailable === true ? 0 : Math.max(0, num(value.tokens));
}

function activeTimeTotal(days) {
  return (Array.isArray(days) ? days : []).reduce((sum, day) => sum + num(day.activeTimeMs), 0);
}

function monthlyRollup(days) {
  const byMonth = new Map();
  for (const d of (Array.isArray(days) ? days : [])) {
    const month = String(d.date).slice(0, 7);
    if (month.length !== 7) continue;
    const m = byMonth.get(month) || { month, tokens: 0, cost: 0, activeTimeMs: 0, perClient: {}, perModel: {} };
    m.tokens += num(d.tokens); m.cost += num(d.cost); m.activeTimeMs += num(d.activeTimeMs);
    addPerClient(m.perClient, d.perClient);
    addPerModel(m.perModel, d.perModel);
    byMonth.set(month, m);
  }
  return [...byMonth.values()].sort((a, b) => a.month.localeCompare(b.month));
}

const DEFAULT_CAP_DAYS = 370;

function rollingDailyWindow(days, todayKey, capDays = DEFAULT_CAP_DAYS) {
  const count = Math.max(0, Math.floor(num(capDays)));
  if (count === 0) return [];
  const startKey = dayKeyAddDays(todayKey, -(count - 1));
  return (Array.isArray(days) ? days : []).filter((d) => {
    const key = String(d?.date || '').slice(0, 10);
    return key >= startKey && key <= todayKey;
  });
}

function favoriteModelOf(contributions) {
  const totals = {};
  for (const d of contributions) {
    for (const [model, v] of Object.entries(d.perModel || {})) {
      totals[model] = (totals[model] || 0) + num(v.tokens);
    }
  }
  let best = '';
  let bestTokens = -1;
  for (const [model, t] of Object.entries(totals)) {
    if (t > bestTokens) { best = model; bestTokens = t; }
  }
  return best;
}

// Three-tier output. The daily tier is capped to capDays (default 370) ending at todayKey;
// monthly and summary are derived from the FULL (uncapped) contribution set, so the cap
// never affects lifetime totals.
function compactTokenDays(days) {
  return days.map((day) => ({
    date: day.date, tokens: num(day.tokens),
    perClient: Object.fromEntries(Object.entries(day.perClient || {}).map(([client, value]) => [client, { tokens: num(value.tokens) }]))
  }));
}

function normalizeHistory(graphData, options = {}) {
  const capDays = Number.isFinite(options.capDays) ? options.capDays : DEFAULT_CAP_DAYS;
  const todayKey = String(options.todayKey || localDayKey()).slice(0, 10);
  const full = (graphData && Array.isArray(graphData.contributions) ? graphData.contributions : [])
    .slice()
    .sort((a, b) => a.date.localeCompare(b.date));

  const daily = rollingDailyWindow(full, todayKey, capDays).map((d) => ({ ...d }));
  computeIntensities(daily);

  const monthly = monthlyRollup(full);
  const totalTokens = full.reduce((s, d) => s + num(d.tokens), 0);
  const totalCost = full.reduce((s, d) => s + num(d.cost), 0);
  const messages = full.reduce((s, d) => s + num(d.messages), 0);
  const activeDays = full.reduce((s, d) => s + (num(d.tokens) > 0 ? 1 : 0), 0);
  const peakDayTokens = full.reduce((m, d) => Math.max(m, num(d.tokens)), 0);
  const { currentStreak, longestStreak } = computeStreaks(full, todayKey);
  const timeMetrics = normalizeTimeMetrics(graphData?.timeMetrics);
  const activeTimeMs = timeMetrics ? timeMetrics.totalActiveTimeMs : activeTimeTotal(full);

  return {
    daily,
    monthly,
    tokenDays: compactTokenDays(full),
    coverage: { dailyComplete: true },
    summary: {
      dateMetricsScope: 'lifetime',
      totalTokens, totalCost, activeDays, currentStreak, longestStreak,
      peakDayTokens, favoriteModel: favoriteModelOf(full), messages,
      activeTimeMs,
      ...(timeMetrics ? { timeMetrics } : {})
    }
  };
}

function mergeDailyMaps(histories) {
  const byDate = new Map();
  for (const h of histories) {
    for (const d of (h && Array.isArray(h.daily) ? h.daily : [])) {
      const cur = byDate.get(d.date)
        || {
          date: d.date, tokens: 0, cost: 0, messages: 0, activeTimeMs: 0,
          cacheReadTokens: 0, cacheWriteTokens: 0, outputTokens: 0, unclassifiedTokens: 0,
          tokenComponentsAvailable: true,
          perClient: {}, perModel: {}
        };
      cur.tokens += num(d.tokens); cur.cost += num(d.cost); cur.messages += num(d.messages); cur.activeTimeMs += num(d.activeTimeMs);
      cur.cacheReadTokens += num(d.cacheReadTokens);
      cur.cacheWriteTokens += num(d.cacheWriteTokens);
      cur.outputTokens += num(d.outputTokens);
      cur.unclassifiedTokens += unclassifiedTokensFor(d);
      cur.tokenComponentsAvailable = cur.tokenComponentsAvailable && d.tokenComponentsAvailable === true;
      addPerClient(cur.perClient, d.perClient, true);
      addPerModel(cur.perModel, d.perModel, true);
      byDate.set(d.date, cur);
    }
  }
  return [...byDate.values()].sort((a, b) => a.date.localeCompare(b.date));
}

function mergeMonthlyMaps(histories) {
  const byMonth = new Map();
  for (const h of histories) {
    for (const m of (h && Array.isArray(h.monthly) ? h.monthly : [])) {
      const cur = byMonth.get(m.month) || { month: m.month, tokens: 0, cost: 0, activeTimeMs: 0, perClient: {}, perModel: {} };
      cur.tokens += num(m.tokens); cur.cost += num(m.cost); cur.activeTimeMs += num(m.activeTimeMs);
      addPerClient(cur.perClient, m.perClient);
      addPerModel(cur.perModel, m.perModel);
      byMonth.set(m.month, cur);
    }
  }
  return [...byMonth.values()].sort((a, b) => a.month.localeCompare(b.month));
}

function mergeHistories(histories, options = {}) {
  const list = Array.isArray(histories) ? histories : [];
  const todayKey = String(options.todayKey || localDayKey()).slice(0, 10);
  const capDays = Number.isFinite(options.capDays) ? options.capDays : DEFAULT_CAP_DAYS;

  // Re-cap after merging: an offline device's persisted daily tier no longer
  // advances at collection time, but the aggregate must keep a rolling window.
  // Monthly/lifetime data remains durable and uncapped.
  const daily = rollingDailyWindow(mergeDailyMaps(list), todayKey, capDays);
  computeIntensities(daily);
  const monthly = mergeMonthlyMaps(list);

  const totalTokens = monthly.reduce((s, m) => s + num(m.tokens), 0);
  const totalCost = monthly.reduce((s, m) => s + num(m.cost), 0);
  const messages = monthly.reduce((s, m) => {
    for (const v of Object.values(m.perClient || {})) s += num(v.messages);
    return s;
  }, 0);
  const dailyComplete = list.every((history) => history?.coverage?.dailyComplete === true && Array.isArray(history.tokenDays));
  const tokenDays = compactTokenDays(mergeDailyMaps(list.map((history) => ({ daily: history?.tokenDays || history?.daily }))));
  const dateEvidence = dailyComplete ? tokenDays : daily;
  const activeDays = dateEvidence.reduce((s, d) => s + (num(d.tokens) > 0 ? 1 : 0), 0);
  const peakDayTokens = dateEvidence.reduce((mx, d) => Math.max(mx, num(d.tokens)), 0);
  const { currentStreak, longestStreak } = computeStreaks(dateEvidence, todayKey);
  const favoriteModel = favoriteModelOf(monthly.length ? monthly : daily);
  const activeTimeMs = activeTimeTotal(monthly.length ? monthly : daily);

  return {
    daily,
    monthly,
    tokenDays,
    coverage: { dailyComplete },
    summary: {
      dateMetricsScope: dailyComplete ? 'lifetime' : 'retained',
      totalTokens, totalCost, activeDays, currentStreak, longestStreak,
      peakDayTokens, favoriteModel, messages, activeTimeMs
    }
  };
}

// Defensively normalize arbitrary wire JSON to the { daily, monthly, summary } shape.
function coerceHistory(raw) {
  const src = raw && typeof raw === 'object' ? raw : {};
  return {
    daily: Array.isArray(src.daily) ? src.daily : [],
    monthly: Array.isArray(src.monthly) ? src.monthly : [],
    summary: src.summary && typeof src.summary === 'object' ? src.summary : {},
    ...(Array.isArray(src.tokenDays) ? {
      tokenDays: src.tokenDays,
      coverage: { dailyComplete: src.coverage?.dailyComplete === true }
    } : {})
  };
}

// Trim a full History to a compact, per-client-free payload for /api/stats.
function historyPreview(history, options = {}) {
  const dailyDays = Number.isFinite(options.dailyDays) ? options.dailyDays : 30;
  const monthlyMonths = Number.isFinite(options.monthlyMonths) ? options.monthlyMonths : 12;
  const h = coerceHistory(history);
  const daily = h.daily.slice(-dailyDays).map((d) => ({ date: d.date, tokens: num(d.tokens), cost: num(d.cost), activeTimeMs: num(d.activeTimeMs) }));
  const monthly = h.monthly.slice(-monthlyMonths).map((m) => ({ month: m.month, tokens: num(m.tokens), cost: num(m.cost), activeTimeMs: num(m.activeTimeMs) }));
  return { daily, monthly, summary: h.summary };
}

function stableJson(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value) ?? 'null';
  if (Array.isArray(value)) return `[${value.map(stableJson).join(',')}]`;
  const entries = Object.keys(value)
    .filter((key) => value[key] !== undefined)
    .sort()
    .map((key) => `${JSON.stringify(key)}:${stableJson(value[key])}`);
  return `{${entries.join(',')}}`;
}

// Compact, deterministic invalidation token for the full history payload. This
// includes daily/monthly breakdowns (not just headline totals), stays portable
// to the Worker runtime, and keeps /api/stats small.
function stableRevision(value) {
  const source = stableJson(value);
  let first = 0x811c9dc5;
  let second = 0x9e3779b9;
  for (let i = 0; i < source.length; i += 1) {
    const code = source.charCodeAt(i);
    first = Math.imul(first ^ code, 0x01000193);
    second = Math.imul(second ^ code, 0x85ebca6b);
  }
  return `${(first >>> 0).toString(16).padStart(8, '0')}${(second >>> 0).toString(16).padStart(8, '0')}`;
}

function historyRevision(history) {
  return stableRevision(coerceHistory(history));
}

// The aggregate History hash cannot detect attribution-only changes such as two
// devices exchanging otherwise identical daily rows. Keep the public stats
// payload small while ensuring renderer caches follow the per-device source of
// each History record, including explicit missing/unavailable states.
function deviceHistoryRevision(devices) {
  const entries = (Array.isArray(devices) ? devices : [])
    .map((record) => {
      const deviceId = String(record?.deviceId || record?.id || '').trim();
      if (!deviceId) return null;
      const hasHistory = Object.prototype.hasOwnProperty.call(record || {}, 'history');
      const hasAvailability = Object.prototype.hasOwnProperty.call(record || {}, 'historyAvailable');
      return {
        deviceId,
        historyAvailable: hasAvailability ? record.historyAvailable === true : 'missing',
        history: !hasHistory
          ? 'missing'
          : record.history === null
            ? 'unavailable'
            : historyRevision(record.history)
      };
    })
    .filter(Boolean)
    .sort((left, right) => left.deviceId.localeCompare(right.deviceId));
  return stableRevision(entries);
}

module.exports = {
  hasDisjointReasoning, num, normalizeTokscaleClientName, normalizeTokscaleModelNameForClient,
  normalizeTokscaleModelComponentSummary, sumOutputTokens, sumTokens,
  parseGraphResult, computeIntensities, localDayKey, dayKeyAddDays,
  computeStreaks, monthlyRollup, normalizeHistory, mergeHistories,
  coerceHistory, historyPreview, historyRevision, deviceHistoryRevision, stableRevision
};
