'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { isDeepStrictEqual } = require('node:util');
const { sharedDataDir, writeJsonAtomic } = require('./config');
const {
  normalizeTokscaleClientName, normalizeTokscaleModelNameForClient,
  normalizeTokscaleModelComponentSummary, num, sumOutputTokens, sumTokens
} = require('./history');
const {
  CLIENT_IDENTITY_GENERATION, CLIENT_IDENTITY_SPLITS, isPreSplitEntry
} = require('./clientIdentitySplits');

const ARCHIVE_VERSION = 1;
const DAY_KEY_RE = /^\d{4}-\d{2}-\d{2}$/;

function observationKey(value) {
  return JSON.stringify([
    normalizeTokscaleClientName(value?.client) || 'unknown',
    normalizeTokscaleModelNameForClient(value?.modelId || value?.model || value?.model_id || 'unknown', value?.client)
  ]);
}

function normalizeObservation(value) {
  if (!value || typeof value !== 'object') return null;
  const client = normalizeTokscaleClientName(value.client) || 'unknown';
  const modelId = normalizeTokscaleModelNameForClient(value.modelId || value.model || value.model_id || 'unknown', client);
  const tokens = Math.max(0, Math.round(num(value.tokens)));
  const cost = Math.max(0, num(value.cost));
  const messages = Math.max(0, Math.round(num(value.messages)));
  const reasoningTokens = Math.max(0, Math.round(num(value.reasoningTokens ?? value.reasoning_tokens)));
  const rawCacheReadTokens = Math.max(0, Math.round(num(value.cacheReadTokens ?? value.cache_read_tokens)));
  const rawCacheWriteTokens = Math.max(0, Math.round(num(value.cacheWriteTokens ?? value.cache_write_tokens)));
  const rawOutputTokens = Math.max(0, Math.round(num(value.outputTokens ?? value.output_tokens)));
  const rawComponentTokens = rawCacheReadTokens + rawCacheWriteTokens + rawOutputTokens;
  const componentsFit = rawComponentTokens <= tokens;
  const cacheReadTokens = componentsFit ? rawCacheReadTokens : 0;
  const cacheWriteTokens = componentsFit ? rawCacheWriteTokens : 0;
  const outputTokens = componentsFit ? rawOutputTokens : 0;
  const componentTokens = cacheReadTokens + cacheWriteTokens + outputTokens;
  const hasExplicitUnclassified = Object.prototype.hasOwnProperty.call(value, 'unclassifiedTokens')
    || Object.prototype.hasOwnProperty.call(value, 'unclassified_tokens');
  const unclassifiedTokens = Math.min(Math.max(0, tokens - componentTokens), Math.max(0, Math.round(
    hasExplicitUnclassified
      ? num(value.unclassifiedTokens ?? value.unclassified_tokens)
      : (value.tokenComponentsAvailable === true && componentsFit ? 0 : tokens)
  )));
  // A zero-token synthetic observation has an exact zero component breakdown
  // even when it predates the provenance field. Do not let bookkeeping-only
  // rows make an otherwise exact fixed-range breakdown unavailable.
  const tokenComponentsAvailable = componentsFit
    && componentTokens + unclassifiedTokens <= tokens
    && unclassifiedTokens === 0
    && (tokens === 0 || value.tokenComponentsAvailable === true);
  if (tokens === 0 && cost === 0 && messages === 0) return null;
  return {
    client,
    modelId,
    ...(String(value.providerId || value.provider_id || '').trim()
      ? { providerId: String(value.providerId || value.provider_id).trim() }
      : {}),
    tokens,
    cost,
    messages,
    ...(unclassifiedTokens > 0 ? { unclassifiedTokens } : {}),
    ...(tokenComponentsAvailable ? {
      tokenComponentsAvailable: true,
      ...(cacheReadTokens > 0 ? { cacheReadTokens } : {}),
      ...(cacheWriteTokens > 0 ? { cacheWriteTokens } : {}),
      ...(outputTokens > 0 ? { outputTokens } : {})
    } : {}),
    ...(reasoningTokens > 0 ? { reasoningTokens } : {})
  };
}

function addObservation(previous, candidate) {
  if (!previous) return candidate;
  return normalizeObservation({
    ...candidate,
    providerId: candidate.providerId || previous.providerId,
    tokens: previous.tokens + candidate.tokens,
    cost: previous.cost + candidate.cost,
    messages: previous.messages + candidate.messages,
    reasoningTokens: num(previous.reasoningTokens) + num(candidate.reasoningTokens),
    tokenComponentsAvailable: previous.tokenComponentsAvailable === true
      && candidate.tokenComponentsAvailable === true,
    cacheReadTokens: num(previous.cacheReadTokens) + num(candidate.cacheReadTokens),
    cacheWriteTokens: num(previous.cacheWriteTokens) + num(candidate.cacheWriteTokens),
    outputTokens: num(previous.outputTokens) + num(candidate.outputTokens),
    unclassifiedTokens: num(previous.unclassifiedTokens) + num(candidate.unclassifiedTokens)
  });
}

function normalizeComponentValues(value, totalTokens, exact) {
  const cacheReadTokens = Math.max(0, Math.round(num(value?.cacheReadTokens)));
  const cacheWriteTokens = Math.max(0, Math.round(num(value?.cacheWriteTokens)));
  const outputTokens = Math.max(0, Math.round(num(value?.outputTokens)));
  if (cacheReadTokens + cacheWriteTokens + outputTokens > totalTokens) return null;
  const unclassifiedTokens = Math.min(
    totalTokens - cacheReadTokens - cacheWriteTokens - outputTokens,
    Math.max(0, Math.round(num(value?.unclassifiedTokens
      ?? (exact ? 0 : totalTokens - cacheReadTokens - cacheWriteTokens - outputTokens))))
  );
  return {
    ...(cacheReadTokens > 0 ? { cacheReadTokens } : {}),
    ...(cacheWriteTokens > 0 ? { cacheWriteTokens } : {}),
    ...(outputTokens > 0 ? { outputTokens } : {}),
    ...(unclassifiedTokens > 0 || (!exact && value?.unclassifiedTokens === 0) ? { unclassifiedTokens } : {})
  };
}

function observationTokenMaps(observations) {
  const perClient = {};
  const perModel = {};
  let totalTokens = 0;
  for (const observation of Object.values(observations || {})) {
    const tokens = Math.max(0, Math.round(num(observation?.tokens)));
    totalTokens += tokens;
    perClient[observation.client] = num(perClient[observation.client]) + tokens;
    perModel[observation.modelId] = num(perModel[observation.modelId]) + tokens;
  }
  return { totalTokens, perClient, perModel };
}

function normalizeComponentSummary(value, observations) {
  if (!value || typeof value !== 'object') return null;
  const exact = value.tokenComponentsAvailable === true;
  const tokenMaps = observationTokenMaps(observations);
  const totals = normalizeComponentValues(value, tokenMaps.totalTokens, exact);
  if (!totals) return null;

  const normalizeMap = (source, tokensByKey) => {
    const result = {};
    for (const [key, tokens] of Object.entries(tokensByKey)) {
      const normalized = normalizeComponentValues(source?.[key], tokens, exact);
      if (!normalized) return null;
      if (Object.keys(normalized).length > 0) result[key] = normalized;
    }
    return result;
  };
  const foldComponentMapByClient = (map) => {
    if (!map || typeof map !== 'object') return map;
    const folded = {};
    for (const [rawClient, comp] of Object.entries(map)) {
      const client = normalizeTokscaleClientName(rawClient) || rawClient;
      if (!folded[client]) {
        folded[client] = { ...comp };
      } else {
        folded[client] = {
          cacheReadTokens: num(folded[client].cacheReadTokens) + num(comp?.cacheReadTokens),
          cacheWriteTokens: num(folded[client].cacheWriteTokens) + num(comp?.cacheWriteTokens),
          outputTokens: num(folded[client].outputTokens) + num(comp?.outputTokens),
          unclassifiedTokens: num(folded[client].unclassifiedTokens) + num(comp?.unclassifiedTokens)
        };
      }
    }
    return folded;
  };
  const perClient = normalizeMap(foldComponentMapByClient(value.perClient), tokenMaps.perClient);
  const perModel = normalizeMap(value.perModel, tokenMaps.perModel);
  if (!perClient || !perModel) return null;
  return {
    tokenComponentsAvailable: exact
      && num(totals.unclassifiedTokens) === 0
      && Object.values(perClient).every((entry) => num(entry.unclassifiedTokens) === 0)
      && Object.values(perModel).every((entry) => num(entry.unclassifiedTokens) === 0),
    ...totals,
    perClient,
    perModel
  };
}

function normalizeDay(value, fallbackDate = '') {
  const date = String(value?.date || fallbackDate).slice(0, 10);
  if (!DAY_KEY_RE.test(date)) return null;
  const observations = {};
  const source = Array.isArray(value?.observations)
    ? value.observations
    : Object.values(value?.observations || {});
  for (const raw of source) {
    const observation = normalizeObservation(raw);
    if (!observation) continue;
    const key = observationKey(observation);
    observations[key] = addObservation(observations[key], observation);
  }
  if (Object.keys(observations).length === 0 && num(value?.activeTimeMs) <= 0) return null;
  const componentSummary = normalizeComponentSummary(
    normalizeTokscaleModelComponentSummary(value?.componentSummary, source), observations
  );
  return {
    date,
    activeTimeMs: Math.max(0, Math.round(num(value?.activeTimeMs))),
    // Provenance travels with the day. An archive written before the split has
    // no marker, which is what makes it recognizable as merged-era; a day this
    // version writes carries the current generation and is taken at face value.
    ...(value?.clientIdentityGeneration !== undefined
      ? { clientIdentityGeneration: num(value.clientIdentityGeneration) }
      : {}),
    observations,
    ...(componentSummary ? { componentSummary } : {})
  };
}

function normalizeDailyHistoryArchive(value) {
  const normalized = { version: ARCHIVE_VERSION, days: {} };
  const source = value?.days && typeof value.days === 'object' ? value.days : {};
  for (const [date, rawDay] of Object.entries(source)) {
    const day = normalizeDay(rawDay, date);
    if (day) normalized.days[day.date] = day;
  }
  const liveSource = value?.liveDays && typeof value.liveDays === 'object' ? value.liveDays : {};
  const liveDays = {};
  for (const [date, rawDay] of Object.entries(liveSource)) {
    const day = normalizeDay(rawDay, date);
    if (day) liveDays[day.date] = day;
  }
  if (Object.keys(liveDays).length > 0) normalized.liveDays = liveDays;
  return normalized;
}

function graphsArray(graphs) {
  return (Array.isArray(graphs) ? graphs : [graphs]).filter((graph) => graph && typeof graph === 'object');
}

// A day that was first observed while two clients shared one row keeps that
// merged identity: the archived row already contains both products' usage, so
// replaying a post-split scan of the same day as two rows would count the split
// client twice. Folding is decided by the day's own provenance rather than by
// its current contents, because "holds the merged id and not the split id" is a
// legal post-split state: a day whose first scan sees only Pi looks exactly like
// a merged-era day, and folding it would permanently absorb Oh My Pi into Pi for
// every later scan of that day. A day with no generation marker predates the
// split and is the only kind that may be folded; a day this version wrote carries
// the current generation and is taken at face value.
function foldClientForDate(client, date, options = {}) {
  if (!client) return client;
  const day = options.archive?.days?.[date];
  if (!day || !isPreSplitEntry(day)) return client;
  for (const { merged, split } of CLIENT_IDENTITY_SPLITS) {
    if (client !== split) continue;
    return merged;
  }
  return client;
}

function observationsFromGraphs(graphs, options = {}) {
  const days = new Map();
  for (const graph of graphsArray(graphs)) {
    for (const row of (Array.isArray(graph.contributions) ? graph.contributions : [])) {
      const date = String(row?.date || '').slice(0, 10);
      if (!DAY_KEY_RE.test(date)) continue;
      const day = days.get(date) || { date, activeTimeMs: 0, observations: {} };
      day.activeTimeMs += Math.max(0, Math.round(num(row.activeTimeMs ?? row.active_time_ms)));
      for (const raw of (Array.isArray(row?.clients) ? row.clients : [])) {
        const client = foldClientForDate(normalizeTokscaleClientName(raw?.client), date, options) || 'unknown';
        const candidate = normalizeObservation({
          ...raw,
          client,
          tokens: sumTokens(raw?.tokens, client),
          reasoningTokens: raw?.tokens?.reasoning,
          tokenComponentsAvailable: raw?.tokenComponentsAvailable !== false,
          cacheReadTokens: raw?.tokens?.cacheRead ?? raw?.tokens?.cache_read,
          cacheWriteTokens: raw?.tokens?.cacheWrite ?? raw?.tokens?.cache_write,
          outputTokens: sumOutputTokens(raw?.tokens, client)
        });
        if (!candidate) continue;
        const key = observationKey(candidate);
        day.observations[key] = addObservation(day.observations[key], candidate);
      }
      days.set(date, day);
    }
  }
  return days;
}

function shouldReplaceObservation(previous, incoming) {
  if (!previous) return true;
  if (incoming.tokens !== previous.tokens) return incoming.tokens > previous.tokens;
  if (incoming.messages !== previous.messages) return incoming.messages > previous.messages;
  // Equal usage can legitimately receive corrected pricing or richer metadata.
  // Replace the whole observation so token and cost values always share a source.
  return true;
}

function captureDailyHistoryArchive(existingArchive, graphs, options = {}) {
  const archive = normalizeDailyHistoryArchive(existingArchive);
  const unavailableClients = new Set((options.unavailableClients || []).map(normalizeTokscaleClientName));
  const todayKey = String(options.todayKey || '').slice(0, 10);
  const hasTodayKey = DAY_KEY_RE.test(todayKey);
  const incomingDays = observationsFromGraphs(graphs, { archive });

  for (const [date, incoming] of incomingDays) {
    if (hasTodayKey && date > todayKey) continue;
    const existing = archive.days[date] || null;
    const previous = existing || { date, activeTimeMs: 0, observations: {} };
    // A day already stored without a marker predates the split, so it keeps that
    // status: its observations genuinely span both products and must keep folding.
    // Anything else is written at the current generation, which is what stops a
    // post-split day from being absorbed into the merged id when Pi happens to be
    // scanned first.
    const legacy = existing !== null && isPreSplitEntry(existing);
    const next = {
      date,
      activeTimeMs: Math.max(previous.activeTimeMs, incoming.activeTimeMs),
      ...(legacy ? {} : { clientIdentityGeneration: CLIENT_IDENTITY_GENERATION }),
      observations: { ...previous.observations }
    };
    for (const [key, observation] of Object.entries(incoming.observations)) {
      if (unavailableClients.has(observation.client)) continue;
      if (shouldReplaceObservation(previous.observations[key], observation)) {
        next.observations[key] = observation;
      }
    }
    const normalized = normalizeDay(next, date);
    if (normalized) archive.days[date] = normalized;
  }

  // Presentation and sync windows are intentionally applied later by
  // normalizeHistory(). The local archive keeps every observed past day so a
  // future year selector can read it without depending on source transcripts.
  if (hasTodayKey) {
    for (const date of Object.keys(archive.days)) {
      if (date > todayKey) delete archive.days[date];
    }
  }
  return archive;
}

function periodLiveDay(period, date) {
  if (!period || typeof period !== 'object' || !DAY_KEY_RE.test(date)) return null;
  const observations = new Map();
  const addObservation = (client, modelId, tokens, cost) => {
    const observation = {
      client,
      modelId,
      tokens: Math.max(0, Math.round(num(tokens))),
      cost: Math.max(0, num(cost)),
      messages: 0
    };
    const key = observationKey(observation);
    const previous = observations.get(key);
    if (!previous) {
      observations.set(key, observation);
      return;
    }
    previous.tokens += observation.tokens;
    previous.cost += observation.cost;
  };
  const clientModels = period.clientModels && typeof period.clientModels === 'object'
    ? period.clientModels
    : {};
  const clientModelCosts = period.clientModelCosts && typeof period.clientModelCosts === 'object'
    ? period.clientModelCosts
    : {};
  const clients = period.clients && typeof period.clients === 'object' ? period.clients : {};
  const clientCosts = period.clientCosts && typeof period.clientCosts === 'object' ? period.clientCosts : {};
  const clientIds = new Set([...Object.keys(clientModels), ...Object.keys(clients), ...Object.keys(clientCosts)]);

  for (const client of clientIds) {
    const models = clientModels[client] && typeof clientModels[client] === 'object'
      ? clientModels[client]
      : {};
    const modelIds = Object.keys(models);
    let modeledTokens = 0;
    let modeledCost = 0;
    for (const modelId of modelIds) {
      const modelTokens = Math.max(0, Math.round(num(models[modelId])));
      const modelCost = Math.max(0, num(clientModelCosts[client]?.[modelId]));
      addObservation(client, modelId, modelTokens, modelCost);
      modeledTokens += modelTokens;
      modeledCost += modelCost;
    }
    const clientTokens = Math.max(0, Math.round(num(clients[client])));
    const clientCost = Math.max(0, num(clientCosts[client]));
    const remainderTokens = Math.max(0, clientTokens - modeledTokens);
    const remainderCost = Math.max(0, clientCost - modeledCost);
    if (modelIds.length === 0 || remainderTokens > 0 || remainderCost > 0) {
      addObservation(client, 'unknown', remainderTokens, remainderCost);
    }
  }

  const totalTokens = Math.max(0, Math.round(num(period.totalTokens)));
  const totalCost = Math.max(0, num(period.costUsd));
  const observed = [...observations.values()];
  const observedTokens = observed.reduce((sum, observation) => sum + observation.tokens, 0);
  const observedCost = observed.reduce((sum, observation) => sum + observation.cost, 0);
  if (totalTokens > observedTokens || totalCost > observedCost) {
    addObservation(
      'unknown',
      'unknown',
      Math.max(0, totalTokens - observedTokens),
      Math.max(0, totalCost - observedCost)
    );
  }

  const hasKnownComponents = num(period.cacheReadTokens)
    + num(period.cacheWriteTokens)
    + num(period.outputTokens) > 0;
  const componentSummary = totalTokens > 0
    && (period.capabilities?.tokenComponents === true || hasKnownComponents)
    ? {
        tokenComponentsAvailable: period.capabilities?.tokenComponents === true,
        cacheReadTokens: num(period.cacheReadTokens),
        cacheWriteTokens: num(period.cacheWriteTokens),
        outputTokens: num(period.outputTokens),
        unclassifiedTokens: num(period.unclassifiedTokens),
        perClient: Object.fromEntries([...clientIds].map((client) => [client, {
          cacheReadTokens: num(period.clientCacheReads?.[client]),
          cacheWriteTokens: num(period.clientCacheWrites?.[client]),
          outputTokens: num(period.clientOutputs?.[client]),
          unclassifiedTokens: num(period.clientUnclassifiedTokens?.[client])
        }])),
        perModel: Object.fromEntries(Object.keys(period.models || {}).map((model) => [model, {
          cacheReadTokens: num(period.modelCacheReads?.[model]),
          cacheWriteTokens: num(period.modelCacheWrites?.[model]),
          outputTokens: num(period.modelOutputs?.[model]),
          unclassifiedTokens: num(period.modelUnclassifiedTokens?.[model])
        }]))
      }
    : null;
  const day = normalizeDay({
    date,
    activeTimeMs: 0,
    observations: [...observations.values()],
    ...(componentSummary ? { componentSummary } : {})
  }, date);
  return day && Object.keys(day.observations).length > 0 ? day : null;
}

function dayTokens(day) {
  return Object.values(day?.observations || {}).reduce((sum, observation) => sum + num(observation.tokens), 0);
}

function dayCost(day) {
  return Object.values(day?.observations || {}).reduce((sum, observation) => sum + num(observation.cost), 0);
}

function dayComponentQuality(day) {
  if (day?.componentSummary?.tokenComponentsAvailable === true) return 2;
  if (day?.componentSummary) return 1;
  const usage = Object.values(day?.observations || {}).filter((observation) => num(observation.tokens) > 0);
  if (usage.length === 0 || usage.every((observation) => observation.tokenComponentsAvailable === true)) return 2;
  return usage.some((observation) => (
    num(observation.cacheReadTokens) > 0
    || num(observation.cacheWriteTokens) > 0
    || num(observation.outputTokens) > 0
  )) ? 1 : 0;
}

function liveDayIsGreater(incoming, previous) {
  const incomingTokens = dayTokens(incoming);
  const previousTokens = dayTokens(previous);
  if (incomingTokens !== previousTokens) return incomingTokens > previousTokens;
  const qualityDifference = dayComponentQuality(incoming) - dayComponentQuality(previous);
  if (qualityDifference !== 0) return qualityDifference > 0;
  // Equal usage can receive a corrected price in either direction. The later
  // live observation is authoritative once its provenance quality is equal.
  return dayCost(incoming) !== dayCost(previous);
}

// A Cursor liveDay keeps the cost of the moment it was captured, while the
// graph reprices that day's same events on every scan. For Cursor usage both
// hold, the graph's cost is the current one and the liveDay's only fills a
// graph cost that is missing. That holds whichever day liveDayIsGreater keeps:
// a liveDay chosen because another observation grew must not carry a stale
// Cursor cost along, and a graph day kept because the aggregate cost happened
// to tie must still take a price only the liveDay has. Every other client keeps
// the bidirectional repricing liveDayIsGreater allows.
function withReconciledCursorCosts(day, graphDay, liveDay) {
  let changed = false;
  const observations = Object.fromEntries(Object.entries(day.observations).map(([key, observation]) => {
    const graphObservation = graphDay.observations[key];
    const liveObservation = liveDay.observations[key];
    if (normalizeTokscaleClientName(observation.client) !== 'cursor'
      || !graphObservation
      || !liveObservation
      || num(graphObservation.tokens) !== num(liveObservation.tokens)) {
      return [key, observation];
    }
    const cost = num(graphObservation.cost) > 0 ? graphObservation.cost : liveObservation.cost;
    if (num(cost) === num(observation.cost)) return [key, observation];
    changed = true;
    return [key, { ...observation, cost }];
  }));
  return changed ? { ...day, observations } : day;
}

function mergeLiveDayMetadata(liveDay, previousDay) {
  if (!previousDay) return liveDay;
  const observations = Object.fromEntries(Object.entries(liveDay.observations).map(([key, observation]) => {
    const previous = previousDay.observations[key];
    if (!previous) return [key, observation];
    if (liveDay.componentSummary) {
      return [key, {
        ...observation,
        messages: Math.max(observation.messages, previous.messages),
        ...(Math.max(num(observation.reasoningTokens), num(previous.reasoningTokens)) > 0
          ? { reasoningTokens: Math.max(num(observation.reasoningTokens), num(previous.reasoningTokens)) }
          : {})
      }];
    }
    const incomingTokens = num(observation.tokens);
    const previousTokens = num(previous.tokens);
    const canRetainPreviousComponents = incomingTokens >= previousTokens;
    const previousUnclassified = Math.min(previousTokens, num(previous.unclassifiedTokens));
    const unclassifiedTokens = canRetainPreviousComponents
      ? previousUnclassified + (incomingTokens - previousTokens)
      : incomingTokens;
    return [key, {
      ...observation,
      messages: Math.max(observation.messages, previous.messages),
      ...(canRetainPreviousComponents && previousTokens - previousUnclassified > 0 ? {
        cacheReadTokens: num(previous.cacheReadTokens),
        cacheWriteTokens: num(previous.cacheWriteTokens),
        outputTokens: num(previous.outputTokens)
      } : {}),
      ...(unclassifiedTokens > 0 ? { unclassifiedTokens } : {}),
      ...(unclassifiedTokens === 0 ? { tokenComponentsAvailable: true } : {}),
      ...(Math.max(num(observation.reasoningTokens), num(previous.reasoningTokens)) > 0
        ? { reasoningTokens: Math.max(num(observation.reasoningTokens), num(previous.reasoningTokens)) }
        : {})
    }];
  }));
  return {
    ...liveDay,
    activeTimeMs: Math.max(liveDay.activeTimeMs, previousDay.activeTimeMs),
    observations
  };
}

function preserveUnavailableLiveClients(incoming, previous, unavailableClients) {
  if (!incoming || unavailableClients.size === 0) return incoming;
  const parts = [
    [incoming, (client) => !unavailableClients.has(client)],
    [previous, (client) => unavailableClients.has(client)]
  ].filter(([day]) => day).map(([day, keep]) => ({
    day,
    observations: Object.fromEntries(Object.entries(day.observations).filter(([, value]) => keep(value.client)))
  }));
  const observations = Object.assign({}, ...parts.map((part) => part.observations));
  if (isDeepStrictEqual(observations, incoming.observations)) return incoming;
  const sumComponents = (values) => Object.fromEntries(
    ['cacheReadTokens', 'cacheWriteTokens', 'outputTokens', 'unclassifiedTokens']
      .map((key) => [key, values.reduce((sum, value) => sum + num(value?.[key]), 0)])
  );
  const perClient = {}, perModel = {};
  for (const { day, observations: selected } of parts) {
    const allTokens = observationTokenMaps(day.observations);
    const selectedTokens = observationTokenMaps(selected);
    const rows = Object.values(selected);
    for (const [client, tokens] of Object.entries(selectedTokens.perClient)) {
      perClient[client] = day.componentSummary
        ? normalizeComponentValues(day.componentSummary.perClient?.[client], tokens, day.componentSummary.tokenComponentsAvailable)
        : sumComponents(rows.filter((row) => row.client === client));
      perClient[client].unclassifiedTokens ??= 0;
    }
    for (const [model, tokens] of Object.entries(selectedTokens.perModel)) {
      const wholeModelComponents = tokens === allTokens.perModel[model] && day.componentSummary
        ? day.componentSummary.perModel?.[model] || {} : null;
      const selectedComponents = wholeModelComponents
        ? normalizeComponentValues(wholeModelComponents, tokens, day.componentSummary.tokenComponentsAvailable)
        : sumComponents(rows.filter((row) => row.modelId === model));
      perModel[model] = sumComponents([perModel[model], selectedComponents]);
    }
  }
  const componentSummary = {
    tokenComponentsAvailable: [...Object.values(perClient), ...Object.values(perModel)]
      .every((value) => num(value.unclassifiedTokens) === 0),
    ...sumComponents(Object.values(perClient)), perClient, perModel
  };
  return normalizeDay({
    ...incoming, observations, componentSummary,
    activeTimeMs: Math.max(incoming.activeTimeMs, num(previous?.activeTimeMs))
  }, incoming.date);
}

function captureLiveDailyHistory(existingArchive, period, options = {}) {
  const archive = normalizeDailyHistoryArchive(existingArchive);
  const date = String(options.todayKey || '').slice(0, 10);
  if (DAY_KEY_RE.test(date) && archive.liveDays) {
    for (const liveDate of Object.keys(archive.liveDays)) {
      if (liveDate > date) delete archive.liveDays[liveDate];
    }
  }
  const previous = archive.liveDays?.[date];
  const incoming = preserveUnavailableLiveClients(
    periodLiveDay(period, date), previous,
    new Set((options.unavailableClients || []).map(normalizeTokscaleClientName))
  );
  if (!incoming) return archive;
  if (!previous || liveDayIsGreater(incoming, previous)) {
    archive.liveDays = { ...(archive.liveDays || {}), [date]: incoming };
  }
  return archive;
}

function graphTimeMetrics(graphs, activeTimeMs) {
  const source = graphsArray(graphs)
    .map((graph) => graph.timeMetrics ?? graph.time_metrics)
    .find((value) => value && typeof value === 'object');
  if (!source) return null;
  return {
    ...source,
    totalActiveTimeMs: Math.max(
      num(source.totalActiveTimeMs ?? source.total_active_time_ms),
      activeTimeMs
    )
  };
}

function graphFromDailyHistoryArchive(graphs, archive, options = {}) {
  const normalizedArchive = normalizeDailyHistoryArchive(archive);
  const currentDays = observationsFromGraphs(graphs, { archive: normalizedArchive });
  const todayKey = String(options.todayKey || '').slice(0, 10);
  const hasTodayKey = DAY_KEY_RE.test(todayKey);

  for (const [date, day] of Object.entries(normalizedArchive.days)) {
    if (hasTodayKey && date > todayKey) continue;
    currentDays.set(date, day);
  }
  for (const [date, liveDay] of Object.entries(normalizedArchive.liveDays || {})) {
    if (hasTodayKey && date > todayKey) continue;
    const previous = currentDays.get(date);
    if (!previous) {
      currentDays.set(date, liveDay);
    } else {
      const previousClients = observationTokenMaps(previous.observations).perClient;
      const liveClients = observationTokenMaps(liveDay.observations).perClient;
      const keepPrevious = new Set(), keepLive = new Set();
      for (const client of options.unavailableClients || []) {
        const normalized = normalizeTokscaleClientName(client);
        (num(previousClients[normalized]) >= num(liveClients[normalized]) ? keepPrevious : keepLive).add(normalized);
      }
      const graphCandidate = preserveUnavailableLiveClients(previous, liveDay, keepLive);
      const liveCandidate = preserveUnavailableLiveClients(liveDay, previous, keepPrevious);
      const selected = liveDayIsGreater(liveCandidate, graphCandidate)
        ? mergeLiveDayMetadata(liveCandidate, graphCandidate) : graphCandidate;
      currentDays.set(date, withReconciledCursorCosts(selected, graphCandidate, liveCandidate));
    }
  }

  const contributions = [...currentDays.values()]
    .sort((left, right) => left.date.localeCompare(right.date))
    .map((day) => ({
      date: day.date,
      activeTimeMs: day.activeTimeMs,
      ...(day.componentSummary ? { tokenComponentSummary: day.componentSummary } : {}),
      clients: Object.values(day.observations)
        .sort((left, right) => observationKey(left).localeCompare(observationKey(right)))
        .map((observation) => ({
          client: observation.client,
          modelId: observation.modelId,
          ...(observation.providerId ? { providerId: observation.providerId } : {}),
          tokens: {
            input: Math.max(0, observation.tokens
              - num(observation.outputTokens)
              - num(observation.cacheReadTokens)
              - num(observation.cacheWriteTokens)),
            output: num(observation.outputTokens),
            cacheRead: num(observation.cacheReadTokens),
            cacheWrite: num(observation.cacheWriteTokens),
            // Archive observations store one already-aggregated output family.
            // Re-emitting reasoning separately would count it twice.
            reasoning: 0
          },
          tokenComponentsAvailable: observation.tokenComponentsAvailable === true,
          ...(num(observation.unclassifiedTokens) > 0
            ? { unclassifiedTokens: num(observation.unclassifiedTokens) }
            : {}),
          cost: observation.cost,
          messages: observation.messages
        }))
    }));
  const activeTimeMs = contributions.reduce((sum, day) => sum + num(day.activeTimeMs), 0);
  const timeMetrics = graphTimeMetrics(graphs, activeTimeMs);
  return { contributions, ...(timeMetrics ? { timeMetrics } : {}) };
}

function dailyHistoryArchivePath(options = {}) {
  return options.path || path.join(sharedDataDir(options), 'daily-history-archive.json');
}

function validateDailyHistoryArchiveDocument(value, filePath) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`Could not parse JSON in ${filePath}: archive root must be an object`);
  }
  for (const key of ['days', 'liveDays']) {
    if (Object.prototype.hasOwnProperty.call(value, key)
      && (!value[key] || typeof value[key] !== 'object' || Array.isArray(value[key]))) {
      throw new Error(`Could not parse JSON in ${filePath}: ${key} must be an object`);
    }
  }
  return value;
}

function readDailyHistoryArchive(options = {}) {
  const filePath = dailyHistoryArchivePath(options);
  if (typeof options.readJson === 'function') {
    return normalizeDailyHistoryArchive(
      validateDailyHistoryArchiveDocument(options.readJson(filePath, {}), filePath)
    );
  }
  let content;
  try {
    content = fs.readFileSync(filePath, 'utf8');
  } catch (error) {
    if (error?.code === 'ENOENT') return normalizeDailyHistoryArchive({});
    throw error;
  }
  if (!content.trim()) {
    throw new Error(`Could not parse JSON in ${filePath}: archive is empty`);
  }
  let parsed;
  try {
    parsed = JSON.parse(content);
  } catch (error) {
    const parseError = new Error(`Could not parse JSON in ${filePath}: ${error.message}`);
    parseError.cause = error;
    throw parseError;
  }
  return normalizeDailyHistoryArchive(validateDailyHistoryArchiveDocument(parsed, filePath));
}

function writeDailyHistoryArchive(archive, options = {}) {
  const write = options.writeJsonAtomic || writeJsonAtomic;
  write(dailyHistoryArchivePath(options), normalizeDailyHistoryArchive(archive));
}

function clearDailyHistoryArchive(options = {}) {
  const unlink = options.unlinkSync || fs.unlinkSync;
  try {
    unlink(dailyHistoryArchivePath(options));
    return true;
  } catch (error) {
    if (error?.code === 'ENOENT') return false;
    throw error;
  }
}

function mergeLiveDaysIntoArchive(existingArchive, liveDays, options) {
  const archive = normalizeDailyHistoryArchive(existingArchive);
  const incoming = normalizeDailyHistoryArchive({ liveDays }).liveDays || {};
  const unavailableClients = new Set((options.unavailableClients || []).map(normalizeTokscaleClientName));
  for (const [date, liveDay] of Object.entries(incoming)) {
    const previous = archive.liveDays?.[date];
    const candidate = preserveUnavailableLiveClients(liveDay, previous, unavailableClients);
    if (candidate && (!previous || liveDayIsGreater(candidate, previous))) {
      archive.liveDays = { ...(archive.liveDays || {}), [date]: candidate };
    }
  }
  return archive;
}

function archiveWriteEnabled(options = {}) {
  return typeof options.writeEnabled === 'function'
    ? options.writeEnabled() !== false
    : options.writeEnabled !== false;
}

function retainDailyHistory(graphs, options = {}) {
  const previous = readDailyHistoryArchive(options);
  const capture = (archive) => captureDailyHistoryArchive(
    mergeLiveDaysIntoArchive(archive, options.liveDays, options),
    graphs,
    options
  );
  let next = capture(previous);
  // Ownership can change while a graph scan is running (for example, a
  // headless agent starts after Electron's collector tick begins). Resolve a
  // lazy guard immediately before the write instead of freezing it at startup.
  if (archiveWriteEnabled(options) && !isDeepStrictEqual(previous, next)) {
    // The graph scan can take long enough for the other collector to update the
    // shared archive. Rebase on the latest file immediately before writing so
    // this scan cannot put that newer observation back on disk.
    const latest = readDailyHistoryArchive(options);
    next = capture(latest);
    if (archiveWriteEnabled(options) && !isDeepStrictEqual(latest, next)) {
      writeDailyHistoryArchive(next, options);
    }
  }
  return graphFromDailyHistoryArchive(graphs, next, options);
}

function retainLiveDailyHistory(period, options = {}) {
  const previous = readDailyHistoryArchive(options);
  const capture = (archive) => captureLiveDailyHistory(
    mergeLiveDaysIntoArchive(archive, options.liveDays, options),
    period,
    options
  );
  let next = capture(previous);
  if (archiveWriteEnabled(options) && !isDeepStrictEqual(previous, next)) {
    const latest = readDailyHistoryArchive(options);
    next = capture(latest);
    if (archiveWriteEnabled(options) && !isDeepStrictEqual(latest, next)) {
      writeDailyHistoryArchive(next, options);
    }
  }
  return next;
}

module.exports = {
  captureDailyHistoryArchive,
  clearDailyHistoryArchive,
  dailyHistoryArchivePath,
  graphFromDailyHistoryArchive,
  captureLiveDailyHistory,
  normalizeDailyHistoryArchive,
  observationKey,
  readDailyHistoryArchive,
  retainDailyHistory,
  retainLiveDailyHistory,
  shouldReplaceObservation,
  writeDailyHistoryArchive
};
