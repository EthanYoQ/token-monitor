'use strict';

// The AI Tool Limits provider catalog: one entry per wired provider, in the
// order a fresh install gets.
//
// This is the single source of truth for a provider's identity — id, display
// order, and the name every desktop surface shows. Ids are derived from the
// catalog rather than listed again, so the two cannot drift.
//
// Labels live here rather than in a desktop-only module because the split was
// not worth its own file: adding or reordering a provider changes the id list
// anyway, which is what moves the Hub core build id, and a label has been
// renamed on its own exactly once in this project's history. The Worker carries
// a few strings it never reads; that is the whole cost.
//
// Pure data plus one pure function, no DOM and no Node built-ins, so the widget
// renderer can load it as a plain <script>, the Worker can vendor it, and
// node:test can require it.
(function exposeLimitProviders(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.TokenMonitorLimitProviders = api;
})(typeof window !== 'undefined' ? window : null, function createLimitProvidersApi() {
  // Order here IS the provider order: it is what the renderer spreads into
  // DEFAULT_LIMIT_PROVIDER_ORDER, so changing it changes what a fresh install
  // writes to settings. Saved user ordering is parsed separately and must not
  // be overwritten. tests/electron/limitProviderOrder.test.js pins this order.
  //
  // `settingsLabel` overrides `label` wherever the desktop names the provider as
  // a tool you configure or pay for: the AI Tool Limits and Home provider lists,
  // the settings search index, and every subscription surface through
  // subscriptionProviderLabel(). It is not scoped to one list — adding one
  // renames the provider on all of them at once. Surfaces that name a live
  // quota rather than a configured tool keep `label`, as the tray detail does.
  const LIMIT_PROVIDER_CATALOG = Object.freeze([
    { id: 'claude', label: 'Claude', settingsLabel: 'Claude Code' },
    { id: 'codex', label: 'Codex' },
    { id: 'opencode', label: 'OpenCode' },
    { id: 'cursor', label: 'Cursor' },
    { id: 'antigravity', label: 'Antigravity' },
    { id: 'cline', label: 'Cline' },
    { id: 'factory', label: 'Factory Droid' },
    { id: 'kimi', label: 'Kimi' },
    { id: 'grok', label: 'Grok' },
    { id: 'copilot', label: 'GitHub Copilot' },
    { id: 'zed', label: 'Zed' },
    { id: 'commandcode', label: 'Command Code' },
    { id: 'mimo', label: 'Xiaomi MiMo' },
    { id: 'zai', label: 'GLM', settingsLabel: 'Z.ai / GLM' },
    { id: 'zaiteam', label: 'GLM Team' },
    { id: 'kiro', label: 'Kiro' },
    { id: 'workbuddy', label: 'WorkBuddy' },
    { id: 'qoder', label: 'Qoder' },
    { id: 'deepseek', label: 'DeepSeek' },
    { id: 'devin', label: 'Devin' },
    { id: 'typesafe', label: 'TypeSafe' },
    { id: 'openrouter', label: 'OpenRouter' },
    { id: 'minimax', label: 'Minimax' },
    { id: 'volcengine', label: 'Volcengine' },
    { id: 'ollama', label: 'Ollama' },
    { id: 'trae', label: 'Trae CN' },
    { id: 'alibaba', label: 'Alibaba Cloud' },
    { id: 'thirdparty', label: 'Third-party APIs' }
  ].map((provider) => Object.freeze({ ...provider })));

  const LIMIT_PROVIDER_IDS = Object.freeze(LIMIT_PROVIDER_CATALOG.map((provider) => provider.id));
  const LIMIT_PROVIDER_LABELS = Object.freeze(Object.fromEntries(
    LIMIT_PROVIDER_CATALOG.map(({ id, label }) => [id, label])
  ));

  // Collection client ids normally match their Limits provider id. Keep the
  // exceptions explicit here.
  const LIMIT_PROVIDER_BY_CLIENT = Object.freeze({
    droid: 'factory',
    zcode: 'zai',
    qodercn: 'qoder',
    dsh: 'deepseek'
  });

  const LIMIT_PROVIDER_ID_SET = new Set(LIMIT_PROVIDER_IDS);

  // Which provider a tracked client's tokens belong to, or null when the client
  // has no Limits side at all. The identity case is part of the answer: most
  // clients resolve to their own id, and the table above only names the ones
  // that do not.
  //
  // Exported because this question has more than one caller and every caller
  // that answered it locally got a different answer: the Edge Dock reconstructed
  // it by calling the seeding function below with a one-client health record,
  // while the subscription card's usage comparison looked the provider id up in
  // a client-keyed cost map directly, which silently found nothing for every
  // provider whose client is named otherwise.
  function limitProviderForClient(client) {
    const clientId = String(client || '').trim().toLowerCase();
    if (!clientId) return null;
    const provider = LIMIT_PROVIDER_BY_CLIENT[clientId] || clientId;
    return LIMIT_PROVIDER_ID_SET.has(provider) ? provider : null;
  }

  // These are the only window metrics that cross the shared limits schema.
  const LIMIT_WINDOW_METRICS = Object.freeze(['credits', 'spend']);
  const VALID_LIMIT_WINDOW_METRICS = new Set(LIMIT_WINDOW_METRICS);

  // Initial discovery is deliberately narrower than the provider list: only a
  // provider mapped from a currently detected local source can be seeded.
  // Usage-derived client status can remain active after a source disappears, so
  // source health is the authoritative signal here.
  function limitProvidersForDetectedClients(clientHealth) {
    const clients = clientHealth?.clients;
    if (!clients || typeof clients !== 'object' || Array.isArray(clients)) return [];
    const detectedProviders = new Set();
    for (const [client, health] of Object.entries(clients)) {
      if (health?.source?.state !== 'detected') continue;
      const provider = limitProviderForClient(client);
      if (provider) detectedProviders.add(provider);
    }
    return LIMIT_PROVIDER_IDS.filter((provider) => detectedProviders.has(provider));
  }

  return {
    LIMIT_PROVIDER_CATALOG,
    LIMIT_PROVIDER_IDS,
    LIMIT_PROVIDER_LABELS,
    LIMIT_WINDOW_METRICS,
    VALID_LIMIT_WINDOW_METRICS,
    limitProviderForClient,
    limitProvidersForDetectedClients
  };
});
