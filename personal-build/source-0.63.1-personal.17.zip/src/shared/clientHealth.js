'use strict';

// Per-client diagnostics: why a tracked tool shows the number it shows.
//
// `clientStatus` answers "is this client active / waiting / missing" in three
// words, which is enough for a dot in the settings list and not enough for the
// question users actually ask — "why is today 0 when this month has tokens?".
// Answering that needs the signals the collector already computes and then
// throws away: which of a client's source roots exist, whether its self-sync
// last worked, and the most recent day any usage was recorded for it.
//
// Three rules shape the wire form:
//
//   * No paths, no stderr. A source root is identified by a stable id from
//     CLIENT_SOURCE_CHECK_IDS; the absolute path contains the user's home dir
//     and stays in the process that probed it. A failed subprocess reports a
//     code, never its output.
//   * Every tracked client sends the same fixed core, so the hub can recompute
//     `overall` and reject a producer that disagrees with its own inputs.
//     Detail beyond that core is sparse — a healthy client sends none of it.
//   * Everything is a closed enum. The hub downgrades a value it does not
//     recognise rather than storing it, so an older hub in front of a newer
//     agent degrades to `unknown` instead of passing junk through to renderers.
//
// Node-builtin-free: this module is vendored into worker/src/shared/ by
// `npm run sync:worker`.

const { REASONIX_SOURCE_CHECK_ID } = require('./providers/reasonix/paths');
const { DSH_SOURCE_CHECK_ID } = require('./providers/dsh/paths');
const { DEVIN_CLI_SOURCE_CHECK_ID, DEVIN_DESKTOP_SOURCE_CHECK_ID } = require('./providers/devin/paths');

const CLIENT_HEALTH_VERSION = 1;

// healthy      — usage was observed for this client
// waiting      — its sources are present but nothing has been counted yet
// attention    — collection is failing, including a self-sync or local read
// unavailable  — no source root on disk; nothing to read
// unknown      — the producer could not tell, or sent a value this build
//                does not recognise
const CLIENT_HEALTH_OVERALL_STATES = Object.freeze([
  'healthy', 'waiting', 'attention', 'unavailable', 'unknown'
]);

const CLIENT_SOURCE_STATES = Object.freeze(['detected', 'missing', 'unknown']);

// `direct` is the common case: tokscale parses the client's own files and there
// is no fetch step to succeed or fail. Self-synced clients also report `idle`,
// `pending`, or `ok`. A local adapter read can report `failed`, as can a sync.
//
// `unknown` is never produced — it is where an unrecognised value lands. It must
// exist as its own state precisely because `direct` is a positive claim: a
// future producer reporting something like `blocked` would, if collapsed to
// `direct`, tell an older hub there is no fetch step to fail, and a client with
// tokens from an earlier scan would come back out as `healthy`.
const CLIENT_COLLECTION_STATES = Object.freeze([
  'direct', 'idle', 'pending', 'ok', 'failed', 'unknown'
]);

// Additional evidence for a failed self-sync. These values describe the stage
// that failed, not the subprocess's message; the latter may contain paths and
// is never allowed onto the device record.
const CLIENT_SYNC_FAILURE_STAGES = Object.freeze(['spawn', 'timeout', 'process-exit', 'unknown']);
const CLIENT_SYNC_FAILURE_STAGE_SET = new Set(CLIENT_SYNC_FAILURE_STAGES);
const MAX_SYNC_EXIT_CODE = 2 ** 31 - 1;
const CLIENT_SYNC_DETAIL_CODES = Object.freeze([
  'language-server-not-found',
  'rpc-failed',
  'permission-denied',
  'cache-write-failed',
  'invalid-response',
  'network-timeout',
  'network-failed',
  'authentication-failed',
  'sync-lock-present',
  'unknown'
]);
const CLIENT_SYNC_DETAIL_CODE_SET = new Set(CLIENT_SYNC_DETAIL_CODES);
const MAX_SYNC_DETAIL_INPUT_LENGTH = 8 * 1024;

function normalizeClientSyncFailureStage(value) {
  const stage = String(value ?? '').trim().toLowerCase();
  if (!stage) return null;
  return CLIENT_SYNC_FAILURE_STAGE_SET.has(stage) ? stage : 'unknown';
}

function normalizeClientSyncExitCode(value) {
  if (typeof value !== 'number' && typeof value !== 'string') return null;
  const raw = String(value).trim();
  if (!/^\d+$/.test(raw)) return null;
  const code = Number(raw);
  return Number.isSafeInteger(code) && code >= 0 && code <= MAX_SYNC_EXIT_CODE ? code : null;
}

function normalizeClientSyncDetailCode(value) {
  const code = String(value ?? '').trim().toLowerCase();
  if (!code) return null;
  return CLIENT_SYNC_DETAIL_CODE_SET.has(code) ? code : 'unknown';
}

function boundedSyncDetailText(value) {
  const raw = String(value ?? '');
  if (raw.length <= MAX_SYNC_DETAIL_INPUT_LENGTH) return raw;
  let bounded = '';
  let codePoints = 0;
  for (const character of raw) {
    if (codePoints >= MAX_SYNC_DETAIL_INPUT_LENGTH) break;
    bounded += character;
    codePoints += 1;
  }
  return bounded;
}

// Classify only high-confidence, stable substrings from the local sync error.
// The input is used inside the process and the return value is the only part
// that may cross the client-health or diagnostic boundaries.
function classifyClientSyncDetailCode({ client = '', text = '' } = {}) {
  const message = boundedSyncDetailText(text).trim().toLowerCase();
  if (!message) return null;

  if (/permission denied|access is denied|operation not permitted|\beacces\b|\beperm\b/.test(message)) {
    return 'permission-denied';
  }
  if (
    /no space left on device|read-only file system/.test(message)
    || /failed to (?:create|persist|write|save).*(?:cache|artifact|manifest)/.test(message)
    || /(?:cache|artifact|manifest).*(?:write|persist|save).*(?:failed|error)/.test(message)
  ) {
    return 'cache-write-failed';
  }
  if (/session (?:token )?(?:expired|invalid)|invalid (?:api )?token|not authenticated|re-authenticate|unauthorized|forbidden|status\s+(?:401|403)\b/.test(message)) {
    return 'authentication-failed';
  }
  const hasNetworkTimeoutTerm = /\b(?:etimedout|network|https?|request|connect(?:ion)?|socket|tcp|tls|dns)\b/.test(message);
  const hasTimeoutTerm = /\b(?:etimedout|timed out|timeout|deadline exceeded|deadline has elapsed)\b/.test(message);
  if (hasNetworkTimeoutTerm && hasTimeoutTerm) {
    return 'network-timeout';
  }
  if (/malformed.*response|invalid response|expected csv format|failed to parse response|invalid json/.test(message)) {
    return 'invalid-response';
  }
  if (
    client === 'antigravity'
    && /cannot discover .*language servers?|language server.*(?:not found|unavailable)|no .*language servers?/.test(message)
  ) {
    return 'language-server-not-found';
  }
  if (
    client === 'antigravity'
    && (/\brpc\b.*(?:fail|error)|(?:fail|error).*\brpc\b|failed to connect to antigravity rpc/.test(message))
  ) {
    return 'rpc-failed';
  }
  if (
    client === 'antigravity'
    && /antigravity sync lock at .* already exists/.test(message)
  ) {
    return 'sync-lock-present';
  }
  if (/failed to connect|connection refused|connection reset|could not resolve|\bdns\b|\bnetwork\b/.test(message)) {
    return 'network-failed';
  }
  return null;
}

// Stable ids for the source roots the collector probes. One id can stand for
// several paths of the same kind — Copilot's workspaceStorage has a variant per
// platform, Kiro's IDE globalStorage has four — because "the VS Code workspace
// storage is missing" is the useful statement, not which spelling was tried.
// clientSourceRoots() in clientSources.js is where they are assigned;
// tests/shared/clientHealth.test.js fails if the two lists drift apart.
const CLIENT_SOURCE_CHECK_IDS = Object.freeze([
  // Not a host path: a marker found inside a running WSL distro. A client
  // installed only there has no host directory, and its usage is merged into the
  // same periods, so it has to count as a source that exists.
  'wsl-home',
  'amp-threads',
  'antigravity-cli-data',
  'antigravity-extension-data',
  'antigravity-ide-source',
  'cherrystudio-transcripts',
  'claude-cc-switch-db',
  'claude-projects',
  'claude-transcripts',
  'cline-cli-sessions',
  'cline-tasks',
  'codebuddy-extension-logs',
  'codebuddy-projects',
  'codex-sessions',
  'commandcode-projects',
  'custom-scan-path',
  'copilot-data',
  'copilot-otel',
  'copilot-otel-exporter',
  'copilot-session-store',
  DEVIN_CLI_SOURCE_CHECK_ID,
  DEVIN_DESKTOP_SOURCE_CHECK_ID,
  'droid-sessions',
  DSH_SOURCE_CHECK_ID,
  'grok-sessions',
  'grok-unified-log',
  'hermes-home',
  'hermes-profile',
  'kilo-db',
  'kilocode-tasks',
  'kimi-code-sessions',
  'kimi-sessions',
  'kiro-cli-data',
  'kiro-ide-globalstorage',
  'kiro-sessions',
  'lmstudio-server-logs',
  'mimocode-data',
  'mimocode-orca-data',
  'omp-sessions',
  'open-code-review-sessions',
  'opencode-data',
  'openclaw-agents',
  'pi-sessions',
  'proma-sessions',
  'qodercn-db',
  'qodercn-projects',
  REASONIX_SOURCE_CHECK_ID,
  'qwen-projects',
  'tokscale-antigravity-cache',
  'tokscale-cursor-cache',
  'unsloth-db',
  'vscode-workspace-storage',
  'workbuddy-db',
  'workbuddy-projects',
  'zcode-cli-db',
  'zcode-projects',
  'zed-threads'
]);

// Observations worth surfacing that the core three fields cannot state on their
// own. Sent only when they apply, capped, and closed: a renderer maps each to a
// translated sentence, so an unrecognised code has nothing to render.
// There is deliberately no "some roots present, others absent" code. A client's
// roots are alternatives, not dependencies — Antigravity's IDE cache, native
// sources and CLI data are three ways to have it installed — so a partial set is
// what a perfectly normal install looks like. `source.checks` still reports
// which ones were found, as neutral evidence rather than a fault.
const CLIENT_HEALTH_DIAGNOSTIC_CODES = Object.freeze([
  'source-missing',        // no source root found at all
  'sync-failed',           // self-sync failed for an unclassified reason
  'sync-timeout',          // self-sync was killed after its deadline
  'sync-spawn-failed',     // the self-sync subprocess could not be started
  'sync-exit-error',       // the self-sync subprocess exited non-zero
  'sync-lock-present',     // an existing Antigravity sync lock blocked the subprocess
  'no-usage-observed',     // sources are present, all-time usage is zero
  'wsl-detected-no-data'   // a WSL marker was found but the scan returned nothing
]);

// Bounds. The record is per client per device and a hub keeps one per device, so
// every list here is capped rather than trusted — a malformed or hostile ingest
// must not be able to grow the stored document without limit.
const MAX_TRACKED_CLIENTS = 64;
const MAX_CHECKS_PER_CLIENT = 12;
const MAX_DIAGNOSTICS_PER_CLIENT = 4;
const MAX_TIMESTAMP_LENGTH = 32;
// Capping the number of clients is not enough on its own: one key just under the
// ingest body limit would still reach storage.
const MAX_CLIENT_ID_LENGTH = 40;

const OVERALL_SET = new Set(CLIENT_HEALTH_OVERALL_STATES);
const SOURCE_STATE_SET = new Set(CLIENT_SOURCE_STATES);
const COLLECTION_STATE_SET = new Set(CLIENT_COLLECTION_STATES);
const CHECK_ID_SET = new Set(CLIENT_SOURCE_CHECK_IDS);
const DIAGNOSTIC_CODE_SET = new Set(CLIENT_HEALTH_DIAGNOSTIC_CODES);

const DAY_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

// Rejected as client ids rather than merely made safe to assign. The map below
// is null-prototype, so these cannot pollute it — but it is serialized to
// storage and parsed back as an ordinary object, and spread into device records
// on the way to renderers, so the key must not survive that round trip at all.
const PROTOTYPE_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

function defaultClientId(value) {
  return String(value || '').trim().toLowerCase();
}

function boundedCount(value) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) return 0;
  return Math.min(Math.floor(parsed), MAX_CHECKS_PER_CLIENT);
}

function boundedTokens(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
}

function normalizeTimestamp(value) {
  const raw = String(value || '').trim().slice(0, MAX_TIMESTAMP_LENGTH);
  if (!raw) return '';
  const parsed = Date.parse(raw);
  return Number.isFinite(parsed) ? new Date(parsed).toISOString() : '';
}

// Shape alone would accept 2026-99-99, which then renders as the newest day this
// client was active. Round-tripping through UTC is what rejects a date the
// calendar does not have.
function normalizeDay(value) {
  const raw = String(value || '').trim().slice(0, 10);
  if (!DAY_PATTERN.test(raw)) return '';
  const parsed = new Date(`${raw}T00:00:00.000Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === raw ? raw : '';
}

// The one place `overall` is decided. The hub recomputes it from the core rather
// than storing what the producer claimed, so a mismatch between a client's
// inputs and its headline can only ever be a bug in this function.
//
// Order matters. A failing self-sync outranks a missing source because the two
// only coincide for a client whose sources exist (a sync is never attempted
// otherwise), so reaching that branch means there is something actionable to
// report. Usage is checked last: a client can have tokens from an earlier scan
// and still be broken right now.
function deriveClientOverall(health) {
  const sourceState = health?.source?.state;
  const collectionState = health?.collection?.state;
  // An unrecognised input on either axis makes every downstream branch a guess,
  // so it stops here rather than resolving to a state that reads as fine.
  if (!SOURCE_STATE_SET.has(sourceState) || sourceState === 'unknown') return 'unknown';
  if (!COLLECTION_STATE_SET.has(collectionState) || collectionState === 'unknown') return 'unknown';
  if (collectionState === 'failed') return 'attention';
  if (sourceState === 'missing') return 'unavailable';
  if (boundedTokens(health?.data?.liveTokens) > 0) return 'healthy';
  return 'waiting';
}

// The legacy three-state view, for a consumer holding a health record but no
// `clientStatus`. Derived from the same two signals statusFromSignals() reads in
// the collector rather than from `overall`, because the collapse is lossy in the
// other direction: a client whose sync is failing but whose earlier tokens still
// count reads `attention` here and `active` there, and both are correct.
function deriveLegacyClientStatus(health) {
  if (boundedTokens(health?.data?.liveTokens) > 0) return 'active';
  return health?.source?.state === 'detected' ? 'waiting' : 'missing';
}

function normalizeChecks(value) {
  if (!Array.isArray(value)) return [];
  const checks = [];
  const seen = new Set();
  for (const entry of value) {
    if (checks.length >= MAX_CHECKS_PER_CLIENT) break;
    const id = String(entry?.id || '').trim();
    if (!CHECK_ID_SET.has(id) || seen.has(id)) continue;
    seen.add(id);
    checks.push({ id, exists: entry?.exists === true });
  }
  return checks;
}

// A diagnostic that the rest of the record does not support is dropped rather
// than carried: the hub is a trust boundary, so what it stores has to be
// internally consistent, not merely field-by-field in range. `sync-*` describes
// a collection that failed, `source-missing` a source that is absent, and
// `no-usage-observed` a client with nothing counted.
function diagnosticAgreesWithEntry(code, entry) {
  if (code.startsWith('sync-')) return entry.collection.state === 'failed';
  if (code === 'source-missing') return entry.source.state === 'missing';
  // Both halves: "we can read this client and found nothing" is a different
  // statement from "there is nothing to read", and only the first is this code.
  if (code === 'no-usage-observed') return entry.source.state === 'detected' && entry.data.liveTokens === 0;
  return true;
}

function normalizeDiagnostics(value, entry) {
  if (!Array.isArray(value)) return [];
  const diagnostics = [];
  const seen = new Set();
  for (const item of value) {
    if (diagnostics.length >= MAX_DIAGNOSTICS_PER_CLIENT) break;
    const code = String(item?.code || '').trim();
    if (!DIAGNOSTIC_CODE_SET.has(code) || seen.has(code)) continue;
    if (!diagnosticAgreesWithEntry(code, entry)) continue;
    seen.add(code);
    diagnostics.push({ code });
  }
  return diagnostics;
}

// One client's record, canonicalized: the fixed core always, detail only where
// it was sent, and nothing that contradicts anything else in the same entry.
//
// `source.state` is derived from the counts rather than read, which is what
// makes a claim like `missing` alongside three detected roots impossible to
// store. The counts are clamped against each other first, so the derivation has
// something coherent to read.
function normalizeClientHealthEntry(value) {
  const collectionState = String(value?.collection?.state || '').trim();
  const checkedCount = boundedCount(value?.source?.checkedCount);
  const detectedCount = Math.min(boundedCount(value?.source?.detectedCount), checkedCount);
  const entry = {
    source: {
      state: checkedCount === 0 ? 'unknown' : (detectedCount > 0 ? 'detected' : 'missing'),
      detectedCount,
      checkedCount
    },
    collection: {
      state: COLLECTION_STATE_SET.has(collectionState) ? collectionState : 'unknown'
    },
    data: {
      liveTokens: boundedTokens(value?.data?.liveTokens)
    }
  };
  // The counts are the core the hub recomputes `overall` from, so `checks` has to
  // agree with them or go. Dropping the evidence is the safe direction: a
  // renderer with no checks shows a ratio, while one holding checks that
  // contradict the ratio has no way to know which half to believe.
  const checks = normalizeChecks(value?.source?.checks);
  const checksAgree = checks.length === checkedCount && checks.filter((check) => check.exists).length === detectedCount;
  if (checks.length > 0 && checksAgree) entry.source.checks = checks;
  const lastAttemptAt = normalizeTimestamp(value?.collection?.lastAttemptAt);
  if (lastAttemptAt) entry.collection.lastAttemptAt = lastAttemptAt;
  const lastSuccessAt = normalizeTimestamp(value?.collection?.lastSuccessAt);
  if (lastSuccessAt) entry.collection.lastSuccessAt = lastSuccessAt;
  if (entry.collection.state === 'failed') {
    const syncFailureStage = normalizeClientSyncFailureStage(value?.collection?.syncFailureStage);
    if (syncFailureStage) entry.collection.syncFailureStage = syncFailureStage;
    const syncExitCode = normalizeClientSyncExitCode(value?.collection?.syncExitCode);
    if (syncExitCode !== null) entry.collection.syncExitCode = syncExitCode;
    const syncDetailCode = normalizeClientSyncDetailCode(value?.collection?.syncDetailCode);
    if (syncDetailCode) entry.collection.syncDetailCode = syncDetailCode;
  }
  const lastActivityDay = normalizeDay(value?.data?.lastActivityDay);
  if (lastActivityDay) entry.data.lastActivityDay = lastActivityDay;
  const diagnostics = normalizeDiagnostics(value?.diagnostics, entry);
  if (diagnostics.length > 0) entry.diagnostics = diagnostics;
  // Recomputed, never copied — see deriveClientOverall.
  entry.overall = deriveClientOverall(entry);
  return entry;
}

// Validates an inbound `clientHealth` field. Returns null for anything that is
// not a usable document, so a caller can leave the field off the record entirely
// rather than store an empty shell.
//
// `normalizeClientId` is injected because the canonical client-name normalizer
// lives in usage.js, which imports this module; taking it as an argument keeps
// the dependency pointing one way.
function normalizeClientHealth(value, normalizeClientId = defaultClientId) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const source = value.clients;
  // An array passes `typeof === 'object'`, and its indices would be stored as
  // client ids — `clients: [{…}]` becoming a client called "0".
  if (!source || typeof source !== 'object' || Array.isArray(source)) return null;
  // Null-prototype: a client id of `__proto__` would otherwise reassign the
  // map's prototype instead of adding an enumerable entry, leaving a health
  // record that is retained but empty.
  const clients = Object.create(null);
  let count = 0;
  for (const [rawId, entry] of Object.entries(source)) {
    if (count >= MAX_TRACKED_CLIENTS) break;
    if (String(rawId).length > MAX_CLIENT_ID_LENGTH || PROTOTYPE_KEYS.has(rawId)) continue;
    const id = normalizeClientId(rawId);
    if (!id || id.length > MAX_CLIENT_ID_LENGTH || PROTOTYPE_KEYS.has(id)) continue;
    if (Object.prototype.hasOwnProperty.call(clients, id)) continue;
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
    clients[id] = normalizeClientHealthEntry(entry);
    count += 1;
  }
  if (count === 0) return null;
  const health = { version: CLIENT_HEALTH_VERSION, clients };
  // One observation time for the whole record, not one per diagnostic: every
  // entry comes from the same scan, and SARIF-style formats put the stamp on the
  // run for exactly that reason. It matters because a limits-only ingest carries
  // health forward while `updatedAt` moves on, so the record's own age is the
  // only thing left that can say how old the diagnosis is.
  const observedAt = normalizeTimestamp(value.observedAt);
  if (observedAt) health.observedAt = observedAt;
  return health;
}

// Tally by headline state, for a one-line summary above the list.
function countOverall(health) {
  const counts = {};
  for (const state of CLIENT_HEALTH_OVERALL_STATES) counts[state] = 0;
  for (const entry of Object.values(health?.clients || {})) {
    const state = OVERALL_SET.has(entry?.overall) ? entry.overall : 'unknown';
    counts[state] += 1;
  }
  return counts;
}

module.exports = {
  CLIENT_HEALTH_DIAGNOSTIC_CODES,
  CLIENT_HEALTH_OVERALL_STATES,
  CLIENT_HEALTH_VERSION,
  CLIENT_COLLECTION_STATES,
  CLIENT_SYNC_DETAIL_CODES,
  CLIENT_SYNC_FAILURE_STAGES,
  MAX_SYNC_DETAIL_INPUT_LENGTH,
  CLIENT_SOURCE_CHECK_IDS,
  CLIENT_SOURCE_STATES,
  MAX_CHECKS_PER_CLIENT,
  MAX_DIAGNOSTICS_PER_CLIENT,
  MAX_TRACKED_CLIENTS,
  countOverall,
  deriveClientOverall,
  deriveLegacyClientStatus,
  normalizeClientHealth,
  normalizeClientSyncDetailCode,
  normalizeClientSyncExitCode,
  normalizeClientSyncFailureStage,
  classifyClientSyncDetailCode
};
